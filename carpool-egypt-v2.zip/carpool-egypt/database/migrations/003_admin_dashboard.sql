-- 003: read-only admin dashboard permission for staff roles.
INSERT INTO permissions(key, description) VALUES ('admin:dashboard:read', 'View aggregate admin dashboard counts');
INSERT INTO role_permissions(role_key, permission_key) VALUES
 ('support_agent','admin:dashboard:read'), ('verification_reviewer','admin:dashboard:read'),
 ('finance_operator','admin:dashboard:read'), ('administrator','admin:dashboard:read'),
 ('super_administrator','admin:dashboard:read');
