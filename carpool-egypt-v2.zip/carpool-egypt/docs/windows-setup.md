# Windows setup

Tested only on Linux in the authoring environment — the PowerShell script and these steps were **not executed on Windows**. Commands use PowerShell.

## 0. Install prerequisites
1. **Node.js 22 LTS or newer** — https://nodejs.org (verify: `node -v`, `npm -v`).
2. **Docker Desktop** (WSL 2 backend) — https://www.docker.com/products/docker-desktop — start it and wait until it says "running".
3. **Git** is optional; you can unzip the project instead.

## 1A. Automatic (recommended)
```powershell
cd path\to\carpool-egypt
powershell -ExecutionPolicy Bypass -File scripts\windows\setup.ps1
```
It checks Node/Docker, creates `.env` and `apps\api\.env` with **generated** secrets (never overwrites existing files), starts PostgreSQL+PostGIS, runs `npm install`, migrations, and seeds cities with the local-only dev flags.

## 1B. Manual equivalent
```powershell
cd path\to\carpool-egypt
copy .env.docker.example .env
notepad .env                       # set POSTGRES_PASSWORD and JWT_ACCESS_SECRET (>= 32 random characters)
copy .env.example apps\api\.env
notepad apps\api\.env              # DATABASE_URL=postgres://carpool:<same password>@localhost:5432/carpool
                                   # JWT_ACCESS_SECRET=<same value>, TRUST_PROXY=true, DEV_MAIL_OUTBOX=true (local testing only)
docker compose up -d db
npm install
npm run migrate
npm run seed:dev
```
Generate a random secret: `[Convert]::ToBase64String((1..48 | % { Get-Random -Max 256 }) -as [byte[]])`

## 2. Create the first administrator
```powershell
$env:ADMIN_EMAIL = "you@example.com"; $env:ADMIN_PASSWORD = "a-long-password-here"
npm run create-admin
Remove-Item Env:ADMIN_PASSWORD
```
This creates a verified **super administrator** (passwords are never stored in files). MFA is not implemented, so use a strong unique password.

## 3. Run
Open two PowerShell windows in the project folder:
```powershell
npm run dev:api     # API  -> http://localhost:4000/health
npm run dev:web     # Web  -> http://localhost:3000
```
Log in as the administrator → **Admin → Settings**: booking and publishing were switched on by `seed:dev`; leave them off on anything public.

### Try the whole flow
1. Register a driver and a passenger (two browsers/profiles). On the verify page click **Get my verification code** (works only with `DEV_MAIL_OUTBOX=true`).
2. Driver: **Drive → Apply**, add a vehicle. Admin: **Verification** tab → approve both.
3. Driver: **Publish a trip**. Passenger: search, open the trip, book. Driver: approve the request. Passenger: **My bookings**.

## 1C. Without Docker (native PostgreSQL)
1. Install PostgreSQL 16 (EDB installer) and, in **Stack Builder → Spatial Extensions**, **PostGIS**.
2. In `psql` as `postgres`:
```sql
CREATE ROLE carpool WITH LOGIN PASSWORD 'choose-a-password';
CREATE DATABASE carpool OWNER carpool;
\c carpool
CREATE EXTENSION postgis; CREATE EXTENSION citext;
```
3. Set `DATABASE_URL=postgres://carpool:choose-a-password@localhost:5432/carpool` in `apps\api\.env`, then continue from `npm install`.
For tests also create a disposable `carpool_test` database with the same two extensions.

## Troubleshooting
| Symptom | Fix |
|---|---|
| `Invalid environment configuration: ...` | a variable name in the message is missing/short (never the value). Fix `apps\api\.env`. |
| `permission denied to create extension` | create `postgis` and `citext` as a superuser (step 1C) or use the Docker database. |
| Port 3000/4000/5432 in use | stop the other program or change `PORT` / the compose port mapping. |
| Login works but you are logged out on refresh | use `http://localhost:3000` (not the API port); with `NODE_ENV=production` the cookie needs HTTPS. |
| 429 "too many attempts" | auth endpoints are rate limited per IP; wait a minute. |
| Verify page shows no "Get my code" button | set `DEV_MAIL_OUTBOX=true` in `apps\api\.env` and restart the API. |
