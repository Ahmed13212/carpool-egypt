# Testing — what was run, and what was not

## Executed (latest run, Linux sandbox, PostgreSQL 16 + PostGIS 3.4, Node 22)
| Check | Result |
|---|---|
| `npm run lint` (api + web) | clean |
| `npm run typecheck` (api + web) | clean |
| `npm run build` (api `tsc`, web `next build`, 14 routes) | success |
| API tests (`npm run test:api`) | **92 passed**, 11 suites: unit, DB constraints, booking engine, **concurrency**, HTTP e2e (auth, permissions, IDOR, search, admin) |
| Web tests (`npm run test:web`) | **39 passed**, 4 files: Egypt-time/DST conversion, money parsing, i18n key/placeholder parity, API client refresh/retry, form validation, booking idempotency-key behaviour |
| `scripts/smoke.mjs` against the **compiled API + production Next server** | **61/61 checks**: SSR pages in RTL/LTR, proxy, cookies, full driver→admin→passenger→booking→cancel journey, session rotation/theft detection, suspension, audit |
| Standalone web server (what the web image runs) | started and served pages, static assets and the API proxy |
| `npm ci --omit=dev -w apps/<x>` (what the Dockerfiles run) | works; no dev dependencies leak into the runtime install |
| `npm audit --omit=dev` | 0 vulnerabilities |
| Mutation check | removing segment locks/capacity check made 4 of 7 concurrency tests fail |

## NOT tested (be aware)
- **Real browsers.** No browser could be installed in the sandbox, so interactive behaviour (clicks, focus, visual layout at mobile/desktop widths,
  RTL visual polish, keyboard navigation, screen readers) was verified only through jsdom component tests and server-rendered HTML — **not by eye**.
  Please click through the app in Chrome/Firefox/Safari and a phone before trusting the UI.
- Docker images and `docker compose` (no Docker in the sandbox); the Windows PowerShell script (no Windows); the GitHub CI workflow.
- Real e-mail/SMS delivery, payments, push notifications, maps/routing providers — none exist.
- Load/performance, security penetration testing, accessibility audit, backup/restore drill, multi-instance behaviour.
- Cross-tab session refresh uses the Web Locks API; it was reasoned about but not exercised in a browser.

## How to run
```bash
export TEST_DATABASE_URL=postgres://user:pass@localhost:5432/carpool_test   # DISPOSABLE db with postgis+citext (tables are dropped each run)
npm test
# smoke: start API (DEV_MAIL_OUTBOX=true, seed:dev) + web, create an admin, then
SMOKE_ADMIN_EMAIL=... SMOKE_ADMIN_PASSWORD=... npm run smoke
```
