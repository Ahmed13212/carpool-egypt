# Deploying later

**Nothing here has been deployed or executed.** Treat it as a checklist, not evidence. Do not open the service to the public before the
legal, security and integration items in [status.md](status.md) are closed.

## Topology
Browser → **HTTPS reverse proxy** → **web** (Next.js, port 3000) → internal **api** (NestJS, port 4000) → **PostgreSQL + PostGIS**.
The web server proxies `/api/v1/*` to the API, so only the web origin must be public; keep the API and database on a private network.

## Option A — single VPS with Docker Compose
1. Server with Docker. DNS `A` record for your domain.
2. Copy the project, create `.env` from `.env.docker.example`: strong `POSTGRES_PASSWORD`, random `JWT_ACCESS_SECRET`,
   `APP_ENV=production`, **`DEV_MAIL_OUTBOX=false`** (the API refuses to start otherwise).
3. Remove the host port mappings for `db` and `api` from `docker-compose.yml` (keep only `web`), put an HTTPS proxy in front, e.g. Caddy:
   ```
   your-domain.com { reverse_proxy web:3000 }
   ```
   (`APP_ENV=production` sets the refresh cookie `Secure`; it will not work over plain HTTP.)
4. `docker compose up --build -d`, then create the administrator with the `create-admin` command from the README.
5. Leave **booking/publishing OFF** until approvals exist; switch them on in Admin → Settings.

## Option B — split services
- **Database:** managed PostgreSQL 16 **with PostGIS and citext** available (check the provider). Create the app role and run `CREATE EXTENSION postgis; CREATE EXTENSION citext;` as an admin.
- **API:** container from `apps/api/Dockerfile`. Env: see `.env.example` (`NODE_ENV=production`, `DATABASE_URL`, `JWT_ACCESS_SECRET`, `TRUST_PROXY=true`).
  Start command applies migrations and seeds cities, then starts the server. Health: `/health`, readiness (DB): `/ready`.
- **Web:** container from `apps/web/Dockerfile` or `next start`. **`API_URL` is read at build time** (baked into the proxy rewrite): rebuild when the API address changes.
- Use the platform's secret store for `JWT_ACCESS_SECRET` and DB credentials; never commit them.

## Required before real use (not implemented or not done)
- A real e-mail provider (the current adapter delivers nothing) and SMS if wanted. Without e-mail, users cannot verify addresses in production.
- Payment provider and approvals (the API refuses to enable payments).
- Driver/vehicle **document** upload and verification (currently a manual click by a reviewer).
- Shared rate-limit store (Redis) if running more than one API instance; log shipping, error monitoring, uptime alerts.
- MFA for staff accounts; a legal review of the operating model; privacy policy/terms pages; insurance review.

## Backups and rollback (procedure, untested)
- Backup: `pg_dump --format=custom --file=backup.dump "$DATABASE_URL"` on a schedule; copy off-host; **practise a restore** into a scratch database
  (`pg_restore --clean --if-exists -d <db> backup.dump`) before relying on it.
- Migrations are forward-only SQL in `database/migrations`, applied in order, each in a transaction, serialised by an advisory lock. Take a backup **before** deploying a new migration.
- Rollback = redeploy the previous images; if a migration must be undone, restore the pre-deploy backup (there are no automatic down-migrations).

## Production checklist
- [ ] HTTPS everywhere, HSTS at the proxy, `NODE_ENV=production`, `DEV_MAIL_OUTBOX=false`
- [ ] Random `JWT_ACCESS_SECRET` (>=32 chars) and DB password stored in a secret manager
- [ ] DB and API not reachable from the internet; database least-privilege role
- [ ] `npm audit --omit=dev` clean; images rebuilt regularly
- [ ] Booking/publishing/payments flags reviewed; legal sign-off recorded
- [ ] Backups scheduled and a restore rehearsed
- [ ] Monitoring/alerts and log retention configured
