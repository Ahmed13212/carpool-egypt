# Status, limitations and remaining work

This is a **tested pre-launch build, not a production-ready product.** Test evidence is in [testing.md](testing.md).

## Implemented and tested
**Backend (NestJS + PostGIS):** registration, e-mail verification, login, rotating refresh tokens with reuse detection, logout, password reset/change;
permission-based RBAC (server-enforced), immediate suspension, audit log; driver application + manual review, vehicles; trip publishing with validation,
price cap and overlap guard; route-aware search (city or PostGIS proximity); per-segment seat inventory with row locking + DB CHECK; booking engine (instant/approval,
idempotency keys, cancellation, expiry method, trip cancellation); admin dashboard counts, verification queue, user management, settings; public cities and meta endpoints.

**Web (Next.js, TypeScript, Tailwind):** home, search + results, trip details with booking panel, register, login, e-mail verification, forgot/reset password, profile
(+ change password), passenger dashboard (view/cancel), driver dashboard (apply, vehicles, trips), trip publishing form (multi-stop route, per-leg prices, Egypt-time input),
trip management (approve/reject requests, edit, cancel), admin (overview, verification, users, audit, settings). Arabic RTL default with English; loading, empty, error,
validation and success states; modals use native `<dialog>`; skip link, labelled fields, `aria-live` regions.

## Deliberately switched off / not available (and the UI says so)
- **Payments:** no provider, webhooks or refunds. The API refuses to enable `payments_enabled`. The booking page states that no payment is taken.
- **E-mail / SMS / notifications:** nothing is delivered. Verification and reset codes are only reachable through the **dev mail outbox** (`DEV_MAIL_OUTBOX=true`, refused in production).
  Passengers must check *My bookings* for driver decisions.
- **Document verification:** no upload/checks; approvals are a manual reviewer click and the admin UI says so.
- `trip_publishing_enabled` and `booking_enabled` default to **OFF** in migrations; `seed:dev` turns them on for local use only.

## Not implemented
Messaging · reviews/ratings · support tickets/incidents · payments/refunds/payouts/ledger · real mail/SMS · push · document storage (S3) · MFA · phone verification ·
account deletion/consent records · routing-provider abstraction and map views · driver public profiles · completed/no-show/in-progress lifecycle endpoints ·
admin trip/booking lists and financial reports · worker/queue (BullMQ/Redis) and automatic expiry scheduling · OpenAPI document · Terms/Privacy/Help/Safety pages ·
load tests · monitoring · legal research.

## Known limitations and risks
- **UI not verified in real browsers** (see testing.md). Mobile layout and RTL visuals need a human pass.
- `BookingsService.expireStale` exists and is tested but **nothing schedules it**; unanswered requests stay holding seats past their expiry until it runs.
- Rate limiting is in-process memory (per instance). Behind the Next proxy the API needs `TRUST_PROXY=true` so limits apply per client IP, not per proxy.
- Registration reveals whether an e-mail is registered (409); password reset does not.
- A 15-minute access token is kept in memory and silently refreshed; two tabs refreshing at once are serialised with the Web Locks API (browsers without it could trip theft detection and be logged out).
- Departure times are entered/displayed in Egypt time using the browser's Intl time-zone data.
- Suspending a driver does not cancel their trips/bookings. Search ignores ratings/vehicle preferences; proximity is straight-line, not road distance.
- Docker, compose, the PowerShell script and CI workflow are untested.

## Needs credentials / approvals before launch
Mail provider, SMS provider (optional), payment merchant approval (Paymob or other), map/routing provider, S3-compatible storage, hosting + domain + HTTPS, error monitoring,
and **legal review** (Law 87/2018 transport licensing, Law 151/2020 data protection, payments/tax, insurance, consumer/e-contract rules).

## Suggested next steps
1. Click-through QA in real browsers + phones; fix visual/RTL issues. 2. Scheduler (worker) for booking expiry + notification outbox with a real mail provider.
3. Document upload with private storage for driver/vehicle verification. 4. Reviews, messaging, support. 5. Payment sandbox adapter → provider approval.
6. OpenAPI, Terms/Privacy/Safety pages (after legal review). 7. Load testing, security review, backup drill, then a limited pilot.
