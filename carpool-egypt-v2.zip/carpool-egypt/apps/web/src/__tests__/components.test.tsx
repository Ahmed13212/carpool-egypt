import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, vi } from "vitest";
import type { ReactNode } from "react";
import { I18nProvider } from "@/i18n";
import type { Trip } from "@/lib/types";

const push = vi.fn();
vi.mock("next/navigation", () => ({
  useRouter: () => ({ push, replace: push }),
  usePathname: () => "/",
  useSearchParams: () => new URLSearchParams(),
}));
vi.mock("next/link", () => ({
  default: ({ href, children, ...r }: any) => (
    <a href={href} {...r}>
      {children}
    </a>
  ),
}));
const cities = [
  {
    id: "c1",
    slug: "cairo",
    nameAr: "القاهرة",
    nameEn: "Cairo",
    governorate: null,
    lat: 30,
    lng: 31,
  },
  {
    id: "c2",
    slug: "asyut",
    nameAr: "أسيوط",
    nameEn: "Asyut",
    governorate: null,
    lat: 27,
    lng: 31,
  },
];
vi.mock("@/lib/cities", () => ({
  useCities: () => ({
    cities,
    loading: false,
    error: undefined,
    bySlug: new Map(cities.map((c) => [c.slug, c])),
    byId: new Map(cities.map((c) => [c.id, c])),
  }),
  cityLabel: (c: any, l: string, f = "") =>
    c ? (l === "ar" ? c.nameAr : c.nameEn) : f,
}));
const authState: any = {
  status: "authed",
  user: { id: "u1", emailVerified: true, email: "a@b.co" },
  meta: { features: { booking: true, tripPublishing: true, payments: false } },
};
vi.mock("@/components/auth-provider", () => ({ useAuth: () => authState }));
const apiMock = vi.fn();
vi.mock("@/lib/api", async (orig) => ({
  ...(await orig<typeof import("@/lib/api")>()),
  api: (...a: unknown[]) => apiMock(...a),
}));

import { BookingPanel } from "@/components/booking-panel";
import { SearchForm } from "@/components/search-form";

const wrap = (ui: ReactNode, locale: "ar" | "en" = "en") =>
  render(<I18nProvider initialLocale={locale}>{ui}</I18nProvider>);

describe("SearchForm", () => {
  beforeEach(() => push.mockReset());
  it("shows validation errors and does not navigate when cities are missing", async () => {
    wrap(<SearchForm />);
    await userEvent.click(screen.getByRole("button", { name: "Search" }));
    expect(screen.getAllByRole("alert")).toHaveLength(2); // origin and destination errors
    expect(push).not.toHaveBeenCalled();
  });
  it("rejects identical origin and destination", async () => {
    wrap(<SearchForm />);
    await userEvent.selectOptions(
      screen.getByLabelText("Leaving from"),
      "cairo",
    );
    await userEvent.selectOptions(screen.getByLabelText("Going to"), "cairo");
    await userEvent.click(screen.getByRole("button", { name: "Search" }));
    expect(screen.getByText("Choose two different cities")).toBeInTheDocument();
    expect(push).not.toHaveBeenCalled();
  });
  it("navigates to results with the chosen filters", async () => {
    wrap(<SearchForm />);
    await userEvent.selectOptions(
      screen.getByLabelText("Leaving from"),
      "cairo",
    );
    await userEvent.selectOptions(screen.getByLabelText("Going to"), "asyut");
    await userEvent.selectOptions(screen.getByLabelText("Passengers"), "2");
    await userEvent.click(screen.getByRole("button", { name: "Search" }));
    expect(push).toHaveBeenCalledWith("/search?from=cairo&to=asyut&seats=2");
  });
  it("renders Arabic labels with city names in Arabic", () => {
    wrap(<SearchForm />, "ar");
    expect(screen.getByLabelText("المغادرة من")).toBeInTheDocument();
    expect(
      screen.getAllByRole("option", { name: "القاهرة" }).length,
    ).toBeGreaterThan(0);
  });
});

const trip: Trip = {
  id: "t1",
  status: "scheduled",
  departureAt: "2030-01-01T10:00:00Z",
  arrivalAt: "2030-01-01T16:00:00Z",
  seatsTotal: 3,
  bookingMode: "instant",
  currency: "EGP",
  notes: null,
  driver: { id: "d1", fullName: "Driver", verified: true },
  vehicle: { make: "Toyota", model: "Corolla", color: "White", seats: 5 },
  stops: [
    {
      id: "s0",
      seq: 0,
      cityId: "c1",
      city: "cairo",
      name: "Ramses",
      lat: 30,
      lng: 31,
      offsetMinutes: 0,
      estimatedAt: "2030-01-01T10:00:00Z",
    },
    {
      id: "s1",
      seq: 1,
      cityId: "c2",
      city: "asyut",
      name: "Station",
      lat: 27,
      lng: 31,
      offsetMinutes: 360,
      estimatedAt: "2030-01-01T16:00:00Z",
    },
  ],
  segments: [
    {
      seq: 0,
      fromStopId: "s0",
      toStopId: "s1",
      priceMinor: 10000,
      seatsAvailable: 2,
    },
  ],
};

describe("BookingPanel", () => {
  beforeEach(() => {
    apiMock.mockReset();
    authState.status = "authed";
    authState.user = { id: "u1", emailVerified: true, email: "a@b.co" };
  });

  it("reuses the SAME Idempotency-Key when the same request is retried after a failure", async () => {
    apiMock
      .mockRejectedValueOnce(
        Object.assign(new Error("net"), { code: "network_error" }),
      )
      .mockResolvedValueOnce({ id: "b1", status: "confirmed" });
    const onBooked = vi.fn();
    wrap(<BookingPanel trip={trip} initial={{}} onBooked={onBooked} />);
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    await screen.findByRole("alert");
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    await screen.findByText("Your booking is confirmed.");
    const keys = apiMock.mock.calls.map((c) => c[1].headers["Idempotency-Key"]);
    expect(keys).toHaveLength(2);
    expect(keys[0]).toBe(keys[1]);
    expect(apiMock.mock.calls[1][1].body).toEqual({
      fromStopId: "s0",
      toStopId: "s1",
      seats: 1,
    });
  });

  it("uses a NEW key when the request changes (different seat count)", async () => {
    apiMock
      .mockRejectedValueOnce(
        Object.assign(new Error("x"), { code: "seat_unavailable" }),
      )
      .mockResolvedValueOnce({ id: "b1", status: "confirmed" });
    wrap(<BookingPanel trip={trip} initial={{}} onBooked={vi.fn()} />);
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    await screen.findByRole("alert");
    await userEvent.selectOptions(
      screen.getByLabelText("Number of seats"),
      "2",
    );
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    await waitFor(() => expect(apiMock).toHaveBeenCalledTimes(2));
    expect(apiMock.mock.calls[0][1].headers["Idempotency-Key"]).not.toBe(
      apiMock.mock.calls[1][1].headers["Idempotency-Key"],
    );
  });

  it("computes the total from segment prices and limits seats to what is available", () => {
    wrap(
      <BookingPanel trip={trip} initial={{ seats: 2 }} onBooked={vi.fn()} />,
    );
    expect(
      screen.getByLabelText("Number of seats").querySelectorAll("option"),
    ).toHaveLength(2);
    expect(screen.getAllByText(/200/).length).toBeGreaterThan(0); // 2 seats x EGP 100
  });

  it("blocks unverified users, own trips and anonymous visitors (server still enforces)", () => {
    authState.user = { id: "u1", emailVerified: false, email: "a@b.co" };
    const { unmount } = wrap(
      <BookingPanel trip={trip} initial={{}} onBooked={vi.fn()} />,
    );
    expect(
      screen.getByText("Verify your email address before booking."),
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book" })).toBeDisabled();
    unmount();
    authState.user = { id: "d1", emailVerified: true, email: "d@b.co" };
    const second = wrap(
      <BookingPanel trip={trip} initial={{}} onBooked={vi.fn()} />,
    );
    expect(screen.getByText("This is your own trip.")).toBeInTheDocument();
    second.unmount();
    authState.status = "anon";
    authState.user = null;
    wrap(<BookingPanel trip={trip} initial={{}} onBooked={vi.fn()} />);
    expect(
      screen.getByText("Log in to book seats on this trip."),
    ).toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: "Book" }),
    ).not.toBeInTheDocument();
  });

  it("shows the no-payment notice so users are not misled", () => {
    wrap(<BookingPanel trip={trip} initial={{}} onBooked={vi.fn()} />);
    expect(
      screen.getByText(/No payment is taken on this platform yet/),
    ).toBeInTheDocument();
  });
});
void fireEvent;
