import { afterEach, beforeEach, vi } from "vitest";
import { api, ApiError, getAccessToken, qs, setAccessToken } from "@/lib/api";

const json = (status: number, body?: unknown) =>
  new Response(body === undefined ? null : JSON.stringify(body), { status });

describe("api client", () => {
  const fetchMock = vi.fn();
  beforeEach(() => {
    fetchMock.mockReset();
    vi.stubGlobal("fetch", fetchMock);
    setAccessToken(null);
  });
  afterEach(() => vi.unstubAllGlobals());

  it("sends the bearer token and parses JSON", async () => {
    setAccessToken("tok");
    fetchMock.mockResolvedValueOnce(json(200, { ok: 1 }));
    await expect(api("/me")).resolves.toEqual({ ok: 1 });
    expect(fetchMock.mock.calls[0][1].headers.Authorization).toBe("Bearer tok");
  });

  it("turns API error bodies into ApiError with the stable code", async () => {
    fetchMock.mockResolvedValueOnce(
      json(409, { error: { code: "seat_unavailable", message: "x" } }),
    );
    await expect(api("/x", { auth: false })).rejects.toMatchObject({
      status: 409,
      code: "seat_unavailable",
    });
  });

  it("maps network failures to network_error", async () => {
    fetchMock.mockRejectedValueOnce(new TypeError("failed"));
    await expect(api("/x", { auth: false })).rejects.toMatchObject({
      code: "network_error",
    });
  });

  it("on 401 refreshes once and retries with the new token", async () => {
    setAccessToken("old");
    fetchMock
      .mockResolvedValueOnce(
        json(401, { error: { code: "invalid_token", message: "" } }),
      )
      .mockResolvedValueOnce(json(200, { accessToken: "new" }))
      .mockResolvedValueOnce(json(200, { me: true }));
    await expect(api("/me")).resolves.toEqual({ me: true });
    expect(fetchMock.mock.calls[1][0]).toBe("/api/v1/auth/refresh");
    expect(fetchMock.mock.calls[1][1].headers["X-Requested-With"]).toBe(
      "fetch",
    );
    expect(fetchMock.mock.calls[2][1].headers.Authorization).toBe("Bearer new");
    expect(getAccessToken()).toBe("new");
  });

  it("parallel 401s trigger a single refresh (single-flight)", async () => {
    setAccessToken("old");
    let refreshCalls = 0;
    fetchMock.mockImplementation(async (url: string, init: any) => {
      if (url.endsWith("/auth/refresh")) {
        refreshCalls++;
        return json(200, { accessToken: "new" });
      }
      return init.headers.Authorization === "Bearer new"
        ? json(200, { ok: true })
        : json(401, { error: { code: "invalid_token", message: "" } });
    });
    await Promise.all([api("/a"), api("/b"), api("/c")]);
    expect(refreshCalls).toBe(1);
  });

  it("clears the token and surfaces 401 when refresh fails", async () => {
    setAccessToken("old");
    fetchMock
      .mockResolvedValueOnce(
        json(401, { error: { code: "invalid_token", message: "" } }),
      )
      .mockResolvedValueOnce(
        json(401, { error: { code: "invalid_refresh_token", message: "" } }),
      );
    await expect(api("/me")).rejects.toBeInstanceOf(ApiError);
    expect(getAccessToken()).toBeNull();
  });

  it("qs drops empty values and encodes the rest", () => {
    expect(qs({ a: 1, b: "", c: undefined, d: "x y" })).toBe("?a=1&d=x+y");
    expect(qs({})).toBe("");
  });
});
