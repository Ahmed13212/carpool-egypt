import {
  cairoLocalToIso,
  egpToMinor,
  formatDuration,
  formatMoney,
  newIdempotencyKey,
} from "@/lib/format";
import { safeNext } from "@/lib/validators";

describe("cairoLocalToIso (Egypt wall-clock time -> UTC)", () => {
  it("uses UTC+3 during Egypt summer time", () => {
    expect(cairoLocalToIso("2026-07-15T10:00")).toBe(
      "2026-07-15T07:00:00.000Z",
    );
  });
  it("uses UTC+2 in winter", () => {
    expect(cairoLocalToIso("2026-12-15T10:00")).toBe(
      "2026-12-15T08:00:00.000Z",
    );
  });
  it("rejects malformed input", () => {
    expect(() => cairoLocalToIso("2026-07-15 10:00")).toThrow();
  });
});

describe("egpToMinor", () => {
  it.each([
    ["150", 15000],
    ["150.5", 15050],
    ["150,25", 15025],
    ["0.05", 5],
    ["١٥٠", 15000],
  ])("%s -> %s", (input, minor) => {
    expect(egpToMinor(input as string)).toBe(minor);
  });
  it.each(["", "abc", "-5", "0", "12.345", "1e3", " "])(
    "rejects %j",
    (input) => {
      expect(egpToMinor(input)).toBeNull();
    },
  );
});

describe("formatting", () => {
  it("formats EGP minor units in both locales", () => {
    expect(formatMoney(15000, "en")).toMatch(/150/);
    expect(formatMoney(15050, "en")).toMatch(/150\.50/);
    expect(formatMoney(15000, "ar")).toMatch(/١٥٠/);
  });
  it("formats durations", () => {
    expect(formatDuration(125, "en")).toBe("2h 5m");
    expect(formatDuration(45, "en")).toBe("45m");
    expect(formatDuration(60, "ar")).toContain("س");
  });
  it("generates distinct idempotency keys that satisfy the API pattern", () => {
    const a = newIdempotencyKey(),
      b = newIdempotencyKey();
    expect(a).not.toBe(b);
    expect(a).toMatch(/^[A-Za-z0-9._:-]{8,128}$/);
  });
});

describe("safeNext (open-redirect protection)", () => {
  it("accepts internal paths only", () => {
    expect(safeNext("/trips/1")).toBe("/trips/1");
    for (const bad of [
      "https://evil.test",
      "//evil.test",
      "/\\evil.test",
      "javascript:alert(1)",
      "",
      null,
      undefined,
    ]) {
      expect(safeNext(bad as string | null)).toBe("/dashboard");
    }
  });
});
