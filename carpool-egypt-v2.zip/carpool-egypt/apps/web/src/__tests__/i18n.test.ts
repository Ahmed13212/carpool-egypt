import { ar } from "@/i18n/ar";
import { en } from "@/i18n/en";
import { interpolate } from "@/i18n";

describe("dictionaries", () => {
  it("Arabic and English define exactly the same keys", () => {
    expect(Object.keys(ar).sort()).toEqual(Object.keys(en).sort());
  });
  it("no translation is empty and placeholders match across languages", () => {
    const ph = (s: string) => (s.match(/\{\w+\}/g) ?? []).sort().join(",");
    for (const k of Object.keys(en) as (keyof typeof en)[]) {
      expect(ar[k].trim()).not.toBe("");
      expect({ k, ph: ph(ar[k]) }).toEqual({ k, ph: ph(en[k]) });
    }
  });
  it("every backend error code the API can return has a message in both languages", () => {
    const codes = [
      "unauthorized",
      "invalid_token",
      "invalid_credentials",
      "account_suspended",
      "email_taken",
      "validation_failed",
      "forbidden",
      "not_found",
      "email_not_verified",
      "feature_disabled",
      "seat_unavailable",
      "duplicate_booking",
      "trip_not_bookable",
      "booking_closed",
      "cannot_book_own_trip",
      "invalid_stops",
      "invalid_booking_transition",
      "trip_departed",
      "rate_limited",
      "csrf_check_failed",
      "invalid_refresh_token",
      "trip_overlap",
      "trip_has_bookings",
      "trip_not_editable",
      "trip_not_cancellable",
      "vehicle_not_verified",
      "driver_not_verified",
      "invalid_trip_plan",
      "vehicle_exists",
      "payments_not_available",
      "network_error",
      "idempotency_key_reuse",
      "already_suspended",
      "not_suspended",
      "not_pending",
    ];
    for (const c of codes) {
      expect(en).toHaveProperty(`errors.${c}`);
      expect(ar).toHaveProperty(`errors.${c}`);
    }
  });
  it("interpolates variables", () => {
    expect(interpolate("Page {page} of {pages}", { page: 2, pages: 5 })).toBe(
      "Page 2 of 5",
    );
    expect(interpolate("{x}")).toBe("{x}");
  });
});
