// Plain (non-client) module so both server components and client code can import these constants.
export const LOCALE_COOKIE = "locale";
export const DEFAULT_LOCALE = "ar" as const;
