"use client";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { ar } from "./ar";
import { en, type MsgKey } from "./en";
import { ApiError } from "@/lib/api";
import type { Locale } from "@/lib/format";

const dicts: Record<Locale, Record<MsgKey, string>> = { en, ar };
import { LOCALE_COOKIE } from "./config";
export { LOCALE_COOKIE };

export function interpolate(
  msg: string,
  vars?: Record<string, string | number>,
) {
  return vars
    ? msg.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? `{${k}}`))
    : msg;
}
export function translate(
  locale: Locale,
  key: MsgKey,
  vars?: Record<string, string | number>,
) {
  return interpolate(dicts[locale][key] ?? dicts.en[key] ?? key, vars);
}

interface Ctx {
  locale: Locale;
  dir: "rtl" | "ltr";
  t: (key: MsgKey, vars?: Record<string, string | number>) => string;
  setLocale: (l: Locale) => void;
  errorMessage: (e: unknown) => string;
}
const I18nContext = createContext<Ctx | null>(null);

export function I18nProvider({
  initialLocale,
  children,
}: {
  initialLocale: Locale;
  children: ReactNode;
}) {
  const [locale, setLocaleState] = useState<Locale>(initialLocale);
  const dir: "rtl" | "ltr" = locale === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
  }, [locale, dir]);

  const setLocale = useCallback((l: Locale) => {
    document.cookie = `${LOCALE_COOKIE}=${l}; Path=/; Max-Age=31536000; SameSite=Lax`;
    setLocaleState(l);
  }, []);

  const t = useCallback(
    (key: MsgKey, vars?: Record<string, string | number>) =>
      translate(locale, key, vars),
    [locale],
  );

  const errorMessage = useCallback(
    (e: unknown) => {
      const code = e instanceof ApiError ? e.code : "generic";
      const key = `errors.${code}` as MsgKey;
      return dicts[locale][key]
        ? translate(locale, key)
        : translate(locale, "errors.generic");
    },
    [locale],
  );

  const value = useMemo(
    () => ({ locale, dir, t, setLocale, errorMessage }),
    [locale, dir, t, setLocale, errorMessage],
  );
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const c = useContext(I18nContext);
  if (!c) throw new Error("useI18n must be used inside I18nProvider");
  return c;
}
