export interface Me {
  id: string;
  email: string;
  fullName: string;
  phone: string | null;
  locale: "ar" | "en";
  emailVerified: boolean;
  roles: string[];
  permissions: string[];
}
export interface City {
  id: string;
  slug: string;
  nameAr: string;
  nameEn: string;
  governorate: string | null;
  lat: number;
  lng: number;
}
export interface Meta {
  currency: string;
  mailDelivery: boolean;
  devMailOutbox: boolean;
  features: { tripPublishing: boolean; booking: boolean; payments: boolean };
}
export interface Page<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
}
export interface SearchItem {
  tripId: string;
  bookingMode: "instant" | "approval";
  currency: string;
  from: {
    stopId: string;
    seq: number;
    name: string;
    city: string;
    departAt: string;
  };
  to: {
    stopId: string;
    seq: number;
    name: string;
    city: string;
    arriveAt: string;
  };
  pricePerSeatMinor: number;
  totalPriceMinor: number;
  seatsAvailable: number;
  driver: { id: string; fullName: string };
  vehicle: { make: string; model: string; color: string };
}
export interface TripStop {
  id: string;
  seq: number;
  cityId: string;
  city: string;
  name: string;
  lat: number;
  lng: number;
  offsetMinutes: number;
  estimatedAt: string;
}
export interface TripSegment {
  seq: number;
  fromStopId: string;
  toStopId: string;
  priceMinor: number;
  seatsAvailable: number;
}
export interface Trip {
  id: string;
  status: "scheduled" | "in_progress" | "completed" | "cancelled";
  departureAt: string;
  arrivalAt: string;
  seatsTotal: number;
  bookingMode: "instant" | "approval";
  currency: string;
  notes: string | null;
  driver: { id: string; fullName: string; verified: boolean };
  vehicle: { make: string; model: string; color: string; seats: number };
  stops: TripStop[];
  segments: TripSegment[];
}
export type BookingStatus =
  | "pending_approval"
  | "awaiting_payment"
  | "confirmed"
  | "rejected"
  | "cancelled"
  | "expired"
  | "completed"
  | "no_show";
export interface Booking {
  id: string;
  tripId: string;
  passengerId: string;
  fromStopSeq: number;
  toStopSeq: number;
  seats: number;
  status: BookingStatus;
  priceTotalMinor: number;
  currency: string;
  expiresAt: string | null;
  cancellationReason: string | null;
  createdAt: string;
  updatedAt: string;
}
export interface MyBooking extends Booking {
  tripStatus: Trip["status"];
  driverName: string;
  from: { name: string; city: string; at: string };
  to: { name: string; city: string; at: string };
}
export interface TripBooking extends Booking {
  passengerName: string;
}
export interface Vehicle {
  id: string;
  make: string;
  model: string;
  color: string;
  seats: number;
  plateNumber: string;
  verificationStatus: "pending_review" | "approved" | "rejected" | "suspended";
}
export interface DriverStatus {
  verificationStatus: string;
  rejectionReason: string | null;
}
export interface MyTrip {
  id: string;
  status: Trip["status"];
  departureAt: string;
  arrivalAt: string;
  seatsTotal: number;
  bookingMode: "instant" | "approval";
  activeBookings: number;
}
export interface Dashboard {
  generatedAt: string;
  live: boolean;
  users: { total: number; suspended: number };
  drivers: { pendingReview: number; approved: number };
  vehicles: { pendingReview: number };
  trips: { upcoming: number; cancelled: number; total: number };
  bookings: {
    total: number;
    byStatus: Record<string, number>;
    cancellationRate: number;
  };
}
export interface VerificationQueue {
  documentsReviewed: boolean;
  drivers: {
    userId: string;
    fullName: string;
    email: string;
    appliedAt: string;
  }[];
  vehicles: {
    id: string;
    ownerId: string;
    ownerName: string;
    make: string;
    model: string;
    color: string;
    seats: number;
    plateNumber: string;
    createdAt: string;
  }[];
}
export interface AdminUser {
  id: string;
  email: string;
  fullName: string;
  status: string;
  roles: string[];
  emailVerified: boolean;
  createdAt: string;
}
export interface AuditLog {
  id: number;
  actorId: string | null;
  action: string;
  targetType: string;
  targetId: string | null;
  metadata: Record<string, unknown>;
  createdAt: string;
}
