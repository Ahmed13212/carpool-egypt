"use client";
import { useEffect, useMemo, useState } from "react";
import { api } from "./api";
import type { City } from "./types";
import type { Locale } from "./format";

let cache: City[] | null = null;
let inflight: Promise<City[]> | null = null;
const loadCities = () => {
  if (cache) return Promise.resolve(cache);
  inflight ??= api<City[]>("/cities", { auth: false })
    .then((c) => {
      cache = c;
      return c;
    })
    .finally(() => {
      inflight = null;
    });
  return inflight;
};

export const cityLabel = (
  c: City | undefined,
  locale: Locale,
  fallback = "",
) => (c ? (locale === "ar" ? c.nameAr : c.nameEn) : fallback);

export function useCities() {
  const [cities, setCities] = useState<City[]>(cache ?? []);
  const [loading, setLoading] = useState(!cache);
  const [error, setError] = useState<unknown>();
  useEffect(() => {
    let alive = true;
    loadCities()
      .then((c) => {
        if (alive) {
          setCities(c);
          setLoading(false);
        }
      })
      .catch((e) => {
        if (alive) {
          setError(e);
          setLoading(false);
        }
      });
    return () => {
      alive = false;
    };
  }, []);
  const bySlug = useMemo(
    () => new Map(cities.map((c) => [c.slug, c])),
    [cities],
  );
  const byId = useMemo(() => new Map(cities.map((c) => [c.id, c])), [cities]);
  return { cities, loading, error, bySlug, byId };
}
