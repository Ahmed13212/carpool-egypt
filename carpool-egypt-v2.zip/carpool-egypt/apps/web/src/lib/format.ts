export type Locale = "ar" | "en";
export const TZ = "Africa/Cairo";
const tag = (l: Locale) => (l === "ar" ? "ar-EG" : "en-GB");

export function formatMoney(minor: number, locale: Locale, currency = "EGP") {
  return new Intl.NumberFormat(tag(locale), {
    style: "currency",
    currency,
    maximumFractionDigits: minor % 100 === 0 ? 0 : 2,
  }).format(minor / 100);
}
export const formatDate = (iso: string, locale: Locale) =>
  new Intl.DateTimeFormat(tag(locale), {
    dateStyle: "medium",
    timeZone: TZ,
  }).format(new Date(iso));
export const formatTime = (iso: string, locale: Locale) =>
  new Intl.DateTimeFormat(tag(locale), {
    timeStyle: "short",
    timeZone: TZ,
  }).format(new Date(iso));
export const formatDateTime = (iso: string, locale: Locale) =>
  new Intl.DateTimeFormat(tag(locale), {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: TZ,
  }).format(new Date(iso));
export const formatNumber = (n: number, locale: Locale) =>
  new Intl.NumberFormat(tag(locale)).format(n);
export const formatPercent = (r: number, locale: Locale) =>
  new Intl.NumberFormat(tag(locale), {
    style: "percent",
    maximumFractionDigits: 1,
  }).format(r);
export function formatDuration(minutes: number, locale: Locale) {
  const h = Math.floor(minutes / 60),
    m = minutes % 60;
  const f = (n: number) => formatNumber(n, locale);
  if (locale === "ar")
    return h ? (m ? `${f(h)} س ${f(m)} د` : `${f(h)} س`) : `${f(m)} د`;
  return h ? (m ? `${h}h ${m}m` : `${h}h`) : `${m}m`;
}

/** Parses a `datetime-local` value ("2026-12-01T09:30") as Egypt local time and returns a UTC ISO string.
 *  Uses Intl so Egypt's daylight-saving rules are applied without a date library. */
export function cairoLocalToIso(value: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(value);
  if (!m) throw new Error("Invalid datetime-local value");
  const [y, mo, d, h, mi] = m.slice(1).map(Number);
  const wall = Date.UTC(y, mo - 1, d, h, mi);
  const offsetAt = (utcMs: number) => {
    const parts = Object.fromEntries(
      new Intl.DateTimeFormat("en-US", {
        timeZone: TZ,
        hourCycle: "h23",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })
        .formatToParts(new Date(utcMs))
        .map((p) => [p.type, p.value]),
    );
    const asUtc = Date.UTC(
      +parts.year,
      +parts.month - 1,
      +parts.day,
      +parts.hour,
      +parts.minute,
      +parts.second,
    );
    return asUtc - utcMs;
  };
  let guess = wall - offsetAt(wall);
  guess = wall - offsetAt(guess); // second pass handles DST boundaries
  return new Date(guess).toISOString();
}

/** Minor units from a user-typed EGP amount ("125", "125.5"). Returns null when invalid. */
export function egpToMinor(input: string): number | null {
  const norm = input
    .trim()
    .replace(/[\u0660-\u0669]/g, (c) => String(c.charCodeAt(0) - 0x0660))
    .replace(",", ".");
  if (!/^\d+(\.\d{1,2})?$/.test(norm)) return null;
  const minor = Math.round(parseFloat(norm) * 100);
  return minor > 0 ? minor : null;
}

export const newIdempotencyKey = () =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? `web-${crypto.randomUUID()}`
    : `web-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
