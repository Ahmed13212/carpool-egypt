/** Thin fetch client for the NestJS API (proxied through Next at /api/v1). The access token lives in memory only;
 *  the refresh token is an HttpOnly cookie the browser JavaScript can never read. */
export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

let accessToken: string | null = null;
let refreshing: Promise<string | null> | null = null;
const listeners = new Set<(token: string | null) => void>();

export const setAccessToken = (t: string | null) => {
  accessToken = t;
  listeners.forEach((l) => l(t));
};
export const getAccessToken = () => accessToken;
export const onTokenChange = (fn: (t: string | null) => void) => {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
};

const BASE = "/api/v1";

async function parse(res: Response) {
  if (res.status === 204) return undefined;
  const text = await res.text();
  if (!text) return undefined;
  try {
    return JSON.parse(text);
  } catch {
    return undefined;
  }
}

function toError(status: number, body: any): ApiError {
  const e = body?.error;
  return new ApiError(
    status,
    e?.code ?? (status >= 500 ? "internal_error" : "error"),
    e?.message ?? `Request failed (${status})`,
    e?.details,
  );
}

/** Exchanges the refresh cookie for a new access token. Single-flight so parallel 401s trigger one refresh. */
export function refreshSession(): Promise<string | null> {
  if (!refreshing) {
    refreshing = (async () => {
      try {
        const res = await fetch(`${BASE}/auth/refresh`, {
          method: "POST",
          credentials: "same-origin",
          headers: { "X-Requested-With": "fetch" },
        });
        if (!res.ok) {
          setAccessToken(null);
          return null;
        }
        const body = await res.json();
        setAccessToken(body.accessToken);
        return body.accessToken as string;
      } catch {
        setAccessToken(null);
        return null;
      } finally {
        refreshing = null;
      }
    })();
  }
  return refreshing;
}

export interface RequestOptions {
  method?: string;
  body?: unknown;
  headers?: Record<string, string>;
  auth?: boolean;
  signal?: AbortSignal;
}

export async function api<T = unknown>(
  path: string,
  opts: RequestOptions = {},
): Promise<T> {
  const { method = "GET", body, headers = {}, auth = true, signal } = opts;
  const run = async () => {
    const h: Record<string, string> = { ...headers };
    if (body !== undefined) h["Content-Type"] = "application/json";
    if (auth && accessToken) h.Authorization = `Bearer ${accessToken}`;
    return fetch(`${BASE}${path}`, {
      method,
      headers: h,
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: "same-origin",
      signal,
    });
  };
  let res: Response;
  try {
    res = await run();
  } catch (e) {
    if ((e as Error).name === "AbortError") throw e;
    throw new ApiError(0, "network_error", "Network error");
  }
  if (res.status === 401 && auth && accessToken) {
    const fresh = await refreshSession();
    if (fresh) res = await run();
  }
  const data = await parse(res);
  if (!res.ok) throw toError(res.status, data);
  return data as T;
}

export const qs = (
  params: Record<string, string | number | undefined | null>,
) => {
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries(params))
    if (v !== undefined && v !== null && v !== "") u.set(k, String(v));
  const s = u.toString();
  return s ? `?${s}` : "";
};
