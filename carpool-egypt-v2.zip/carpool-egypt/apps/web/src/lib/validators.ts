export const isEmail = (s: string) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.trim());
export const isPhone = (s: string) => /^\+?[0-9]{8,15}$/.test(s);
export const safeNext = (
  next: string | null | undefined,
  fallback = "/dashboard",
) =>
  next &&
  next.startsWith("/") &&
  !next.startsWith("//") &&
  !next.startsWith("/\\")
    ? next
    : fallback;
