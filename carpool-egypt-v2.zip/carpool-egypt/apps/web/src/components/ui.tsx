"use client";
import {
  useEffect,
  useId,
  useRef,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from "react";
import { useI18n } from "@/i18n";

export const cn = (...c: (string | false | null | undefined)[]) =>
  c.filter(Boolean).join(" ");

type Variant = "primary" | "secondary" | "danger" | "ghost";
const variants: Record<Variant, string> = {
  primary:
    "bg-brand-600 text-white hover:bg-brand-700 disabled:bg-brand-600/50",
  secondary:
    "bg-white text-brand-900 border border-brand-600/30 hover:bg-brand-50 disabled:opacity-50",
  danger: "bg-red-600 text-white hover:bg-red-700 disabled:bg-red-600/50",
  ghost: "text-brand-700 hover:bg-brand-50 disabled:opacity-50",
};

export function Button({
  variant = "primary",
  loading,
  className,
  children,
  disabled,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  loading?: boolean;
}) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition-colors disabled:cursor-not-allowed",
        variants[variant],
        className,
      )}
    >
      {loading && <Spinner className="size-4" />}
      {children}
    </button>
  );
}

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      role="presentation"
      className={cn(
        "inline-block animate-spin rounded-full border-2 border-current border-t-transparent",
        className ?? "size-5",
      )}
    />
  );
}

export function PageSpinner() {
  const { t } = useI18n();
  return (
    <div
      role="status"
      className="flex items-center justify-center gap-3 py-16 text-brand-700"
    >
      <Spinner /> <span>{t("common.loading")}</span>
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      aria-hidden
      className={cn(
        "animate-pulse rounded-lg bg-sand-100",
        className ?? "h-24 w-full",
      )}
    />
  );
}

const fieldBase =
  "w-full min-h-11 rounded-lg border bg-white px-3 py-2 text-sm text-gray-900 placeholder:text-gray-400 focus:border-brand-600 disabled:bg-gray-100";

export function Field({
  label,
  error,
  hint,
  optional,
  children,
  htmlFor,
}: {
  label: string;
  error?: string;
  hint?: string;
  optional?: boolean;
  htmlFor: string;
  children: ReactNode;
}) {
  const { t } = useI18n();
  return (
    <div className="space-y-1">
      <label
        htmlFor={htmlFor}
        className="block text-sm font-medium text-gray-800"
      >
        {label}{" "}
        {optional && (
          <span className="font-normal text-gray-500">
            ({t("common.optional")})
          </span>
        )}
      </label>
      {children}
      {hint && !error && (
        <p id={`${htmlFor}-hint`} className="text-xs text-gray-500">
          {hint}
        </p>
      )}
      {error && (
        <p
          id={`${htmlFor}-err`}
          role="alert"
          className="text-xs font-medium text-red-700"
        >
          {error}
        </p>
      )}
    </div>
  );
}

type FieldProps = {
  id: string;
  label: string;
  error?: string;
  hint?: string;
  optional?: boolean;
};

export function TextInput({
  id,
  label,
  error,
  hint,
  optional,
  className,
  ...rest
}: FieldProps & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <Field
      label={label}
      error={error}
      hint={hint}
      optional={optional}
      htmlFor={id}
    >
      <input
        id={id}
        aria-invalid={!!error}
        aria-describedby={error ? `${id}-err` : hint ? `${id}-hint` : undefined}
        className={cn(
          fieldBase,
          error ? "border-red-500" : "border-gray-300",
          className,
        )}
        {...rest}
      />
    </Field>
  );
}

export function SelectInput({
  id,
  label,
  error,
  hint,
  optional,
  className,
  children,
  ...rest
}: FieldProps & SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <Field
      label={label}
      error={error}
      hint={hint}
      optional={optional}
      htmlFor={id}
    >
      <select
        id={id}
        aria-invalid={!!error}
        aria-describedby={error ? `${id}-err` : undefined}
        className={cn(
          fieldBase,
          error ? "border-red-500" : "border-gray-300",
          className,
        )}
        {...rest}
      >
        {children}
      </select>
    </Field>
  );
}

export function TextArea({
  id,
  label,
  error,
  hint,
  optional,
  className,
  ...rest
}: FieldProps & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <Field
      label={label}
      error={error}
      hint={hint}
      optional={optional}
      htmlFor={id}
    >
      <textarea
        id={id}
        rows={3}
        aria-invalid={!!error}
        className={cn(
          fieldBase,
          error ? "border-red-500" : "border-gray-300",
          className,
        )}
        {...rest}
      />
    </Field>
  );
}

export function Card({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-black/5 bg-white p-5 shadow-sm",
        className,
      )}
    >
      {children}
    </div>
  );
}

const alertStyles = {
  error: "border-red-300 bg-red-50 text-red-900",
  success: "border-green-300 bg-green-50 text-green-900",
  info: "border-sky-300 bg-sky-50 text-sky-900",
  warning: "border-amber-300 bg-amber-50 text-amber-900",
};
export function Alert({
  kind = "info",
  children,
  className,
}: {
  kind?: keyof typeof alertStyles;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      role={kind === "error" ? "alert" : "status"}
      className={cn(
        "rounded-lg border px-4 py-3 text-sm",
        alertStyles[kind],
        className,
      )}
    >
      {children}
    </div>
  );
}

export function EmptyState({
  title,
  text,
  action,
}: {
  title: string;
  text?: string;
  action?: ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-dashed border-brand-600/30 bg-white px-6 py-12 text-center">
      <p className="text-lg font-semibold text-brand-900">{title}</p>
      {text && (
        <p className="mx-auto mt-2 max-w-md text-sm text-gray-600">{text}</p>
      )}
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  );
}

const badgeTones = {
  green: "bg-green-100 text-green-900",
  amber: "bg-amber-100 text-amber-900",
  red: "bg-red-100 text-red-900",
  gray: "bg-gray-100 text-gray-800",
  blue: "bg-sky-100 text-sky-900",
};
export function Badge({
  tone = "gray",
  children,
}: {
  tone?: keyof typeof badgeTones;
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold",
        badgeTones[tone],
      )}
    >
      {children}
    </span>
  );
}

/** Native <dialog>: focus trap, Escape to close and inert background come from the browser. */
export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  return (
    <dialog
      ref={ref}
      aria-labelledby={titleId}
      onClose={onClose}
      onClick={(e) => {
        if (e.target === ref.current) onClose();
      }}
      className="m-auto w-[min(32rem,92vw)] rounded-2xl p-0 shadow-xl backdrop:bg-black/50"
    >
      {open && (
        <div className="space-y-4 p-6">
          <h2 id={titleId} className="text-lg font-bold text-brand-900">
            {title}
          </h2>
          {children}
        </div>
      )}
    </dialog>
  );
}

export function Pagination({
  page,
  pages,
  onChange,
}: {
  page: number;
  pages: number;
  onChange: (p: number) => void;
}) {
  const { t } = useI18n();
  if (pages <= 1) return null;
  return (
    <nav
      aria-label="pagination"
      className="flex items-center justify-between gap-3 pt-4"
    >
      <Button
        variant="secondary"
        disabled={page <= 1}
        onClick={() => onChange(page - 1)}
      >
        {t("common.previous")}
      </Button>
      <span className="text-sm text-gray-600">
        {t("common.page_of", { page, pages })}
      </span>
      <Button
        variant="secondary"
        disabled={page >= pages}
        onClick={() => onChange(page + 1)}
      >
        {t("common.next")}
      </Button>
    </nav>
  );
}

export const PageTitle = ({
  children,
  sub,
}: {
  children: ReactNode;
  sub?: ReactNode;
}) => (
  <div className="mb-6">
    <h1 className="text-2xl font-bold text-brand-900 sm:text-3xl">
      {children}
    </h1>
    {sub && <p className="mt-1 text-gray-600">{sub}</p>}
  </div>
);
