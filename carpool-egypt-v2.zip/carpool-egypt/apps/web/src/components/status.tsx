"use client";
import { useI18n } from "@/i18n";
import type { BookingStatus, Trip } from "@/lib/types";
import { Badge } from "./ui";

const tones: Record<
  BookingStatus,
  "green" | "amber" | "red" | "gray" | "blue"
> = {
  confirmed: "green",
  pending_approval: "amber",
  awaiting_payment: "amber",
  rejected: "red",
  cancelled: "gray",
  expired: "gray",
  completed: "blue",
  no_show: "red",
};
export function BookingStatusBadge({ status }: { status: BookingStatus }) {
  const { t } = useI18n();
  return <Badge tone={tones[status]}>{t(`bstatus.${status}`)}</Badge>;
}
export function TripStatusBadge({ status }: { status: Trip["status"] }) {
  const { t } = useI18n();
  return (
    <Badge
      tone={
        status === "scheduled"
          ? "green"
          : status === "cancelled"
            ? "red"
            : "gray"
      }
    >
      {t(`tstatus.${status}`)}
    </Badge>
  );
}
