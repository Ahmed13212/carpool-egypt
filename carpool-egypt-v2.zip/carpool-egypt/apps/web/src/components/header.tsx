"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { useI18n } from "@/i18n";
import { useAuth } from "./auth-provider";
import { Button, cn } from "./ui";

export function Header() {
  const { t, locale, setLocale } = useI18n();
  const { status, user, logout, can } = useAuth();
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  const links = [
    { href: "/search", label: t("nav.search"), show: true },
    {
      href: "/dashboard",
      label: t("nav.dashboard"),
      show: status === "authed",
    },
    { href: "/driver", label: t("nav.driver"), show: status === "authed" },
    {
      href: "/admin",
      label: t("nav.admin"),
      show: can("admin:dashboard:read"),
    },
  ].filter((l) => l.show);

  const nav = (href: string, label: string) => (
    <Link
      key={href}
      href={href}
      onClick={() => setOpen(false)}
      aria-current={pathname.startsWith(href) ? "page" : undefined}
      className={cn(
        "rounded-lg px-3 py-2 text-sm font-medium hover:bg-brand-50",
        pathname.startsWith(href) ? "text-brand-700" : "text-gray-700",
      )}
    >
      {label}
    </Link>
  );

  return (
    <header className="sticky top-0 z-40 border-b border-black/5 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-2">
        <Link
          href="/"
          className="flex items-center gap-2 text-xl font-extrabold text-brand-700"
          onClick={() => setOpen(false)}
        >
          <span
            aria-hidden
            className="grid size-8 place-items-center rounded-lg bg-brand-600 text-white"
          >
            م
          </span>
          {t("app.name")}
        </Link>

        <nav
          aria-label={t("nav.menu")}
          className="hidden items-center gap-1 md:flex"
        >
          {links.map((l) => nav(l.href, l.label))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <Button
            variant="ghost"
            onClick={() => setLocale(locale === "ar" ? "en" : "ar")}
            aria-label={t("nav.language")}
            lang={locale === "ar" ? "en" : "ar"}
          >
            {locale === "ar" ? "English" : "العربية"}
          </Button>
          {status === "authed" && user ? (
            <>
              <Link
                href="/profile"
                className="rounded-lg px-3 py-2 text-sm font-medium text-gray-800 hover:bg-brand-50"
              >
                {user.fullName}
              </Link>
              <Button
                variant="secondary"
                onClick={async () => {
                  await logout();
                  router.push("/");
                }}
              >
                {t("nav.logout")}
              </Button>
            </>
          ) : status === "anon" ? (
            <>
              <Link
                href="/login"
                className="rounded-lg px-3 py-2 text-sm font-semibold text-brand-700 hover:bg-brand-50"
              >
                {t("nav.login")}
              </Link>
              <Link
                href="/register"
                className="inline-flex min-h-11 items-center rounded-lg bg-brand-600 px-4 text-sm font-semibold text-white hover:bg-brand-700"
              >
                {t("nav.register")}
              </Link>
            </>
          ) : null}
        </div>

        <button
          type="button"
          className="grid size-11 place-items-center rounded-lg hover:bg-brand-50 md:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={t("nav.menu")}
          onClick={() => setOpen((o) => !o)}
        >
          <span aria-hidden className="text-2xl leading-none">
            {open ? "✕" : "☰"}
          </span>
        </button>
      </div>

      {open && (
        <div
          id="mobile-menu"
          className="border-t border-black/5 bg-white px-4 pb-4 md:hidden"
        >
          <nav className="flex flex-col py-2">
            {links.map((l) => nav(l.href, l.label))}
          </nav>
          <div className="flex flex-col gap-2 border-t border-black/5 pt-3">
            {status === "authed" && user ? (
              <>
                <Link
                  href="/profile"
                  onClick={() => setOpen(false)}
                  className="px-3 py-2 text-sm font-medium"
                >
                  {user.fullName}
                </Link>
                <Button
                  variant="secondary"
                  onClick={async () => {
                    setOpen(false);
                    await logout();
                    router.push("/");
                  }}
                >
                  {t("nav.logout")}
                </Button>
              </>
            ) : status === "anon" ? (
              <>
                <Link
                  href="/login"
                  onClick={() => setOpen(false)}
                  className="px-3 py-2 text-sm font-semibold text-brand-700"
                >
                  {t("nav.login")}
                </Link>
                <Link
                  href="/register"
                  onClick={() => setOpen(false)}
                  className="inline-flex min-h-11 items-center justify-center rounded-lg bg-brand-600 text-sm font-semibold text-white"
                >
                  {t("nav.register")}
                </Link>
              </>
            ) : null}
            <Button
              variant="ghost"
              onClick={() => {
                setLocale(locale === "ar" ? "en" : "ar");
                setOpen(false);
              }}
            >
              {locale === "ar" ? "English" : "العربية"}
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}
