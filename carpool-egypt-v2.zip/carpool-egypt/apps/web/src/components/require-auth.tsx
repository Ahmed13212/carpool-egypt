"use client";
import { useRouter, usePathname } from "next/navigation";
import { useEffect, type ReactNode } from "react";
import { useI18n } from "@/i18n";
import { useAuth } from "./auth-provider";
import { Alert, PageSpinner } from "./ui";

/** Client-side convenience only: it redirects and hides screens. Every API call is still authorised by the server. */
export function RequireAuth({
  children,
  permission,
}: {
  children: ReactNode;
  permission?: string;
}) {
  const { status, can } = useAuth();
  const { t } = useI18n();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (status === "anon")
      router.replace(`/login?next=${encodeURIComponent(pathname)}`);
  }, [status, router, pathname]);

  if (status !== "authed") return <PageSpinner />;
  if (permission && !can(permission))
    return <Alert kind="error">{t("admin.forbidden")}</Alert>;
  return <>{children}</>;
}
