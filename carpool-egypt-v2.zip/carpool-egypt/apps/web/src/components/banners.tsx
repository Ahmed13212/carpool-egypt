"use client";
import Link from "next/link";
import { useI18n } from "@/i18n";
import { useAuth } from "./auth-provider";
import { Alert } from "./ui";

export function Banners() {
  const { t } = useI18n();
  const { user, meta, status } = useAuth();
  return (
    <div className="mx-auto max-w-6xl space-y-2 px-4 pt-3">
      <Alert kind="warning" className="text-xs sm:text-sm">
        {t("banner.prelaunch")}
      </Alert>
      {status === "authed" && user && !user.emailVerified && (
        <Alert kind="info">
          {t("banner.verify_email")}{" "}
          <Link
            className="font-semibold underline"
            href={`/verify-email?email=${encodeURIComponent(user.email)}`}
          >
            {t("banner.verify_cta")}
          </Link>
        </Alert>
      )}
      {meta && !meta.features.booking && (
        <Alert kind="warning">{t("banner.booking_disabled")}</Alert>
      )}
    </div>
  );
}

export function Footer() {
  const { t } = useI18n();
  return (
    <footer className="mt-16 border-t border-black/5 bg-white">
      <div className="mx-auto max-w-6xl space-y-2 px-4 py-8 text-sm text-gray-600">
        <p className="font-semibold text-brand-900">
          {t("app.name")} · {t("app.tagline")}
        </p>
        <p>{t("footer.cost_sharing")}</p>
        <p>{t("footer.notice")}</p>
      </div>
    </footer>
  );
}
