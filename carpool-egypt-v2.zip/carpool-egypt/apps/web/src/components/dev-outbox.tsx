"use client";
import { useState } from "react";
import { useI18n } from "@/i18n";
import { api } from "@/lib/api";
import { useAuth } from "./auth-provider";
import { Alert, Button } from "./ui";

/** Shown only when the API reports DEV_MAIL_OUTBOX=true (never in production). Lets a developer fetch mail tokens. */
export function DevOutbox({
  email,
  kind,
  onToken,
}: {
  email: string;
  kind: "email_verification" | "password_reset";
  onToken: (token: string) => void;
}) {
  const { t, errorMessage } = useI18n();
  const { meta } = useAuth();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ kind: "error" | "info"; text: string }>();
  if (!meta?.devMailOutbox || !email) return null;

  async function fetchToken() {
    setBusy(true);
    setMsg(undefined);
    try {
      const items = await api<{ kind: string; token: string }[]>(
        `/dev/outbox?email=${encodeURIComponent(email)}`,
        { auth: false },
      );
      const hit = [...items].reverse().find((i) => i.kind === kind);
      if (hit) onToken(hit.token);
      else setMsg({ kind: "info", text: t("verify.none_found") });
    } catch (e) {
      setMsg({ kind: "error", text: errorMessage(e) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Alert kind="warning" className="space-y-2">
      <p className="font-semibold">{t("verify.dev_title")}</p>
      <p>{t("verify.dev_text")}</p>
      <Button
        type="button"
        variant="secondary"
        loading={busy}
        onClick={fetchToken}
      >
        {t("verify.dev_button")}
      </Button>
      {msg && <p role="status">{msg.text}</p>}
    </Alert>
  );
}
