"use client";
import Link from "next/link";
import { useMemo, useRef, useState } from "react";
import { useI18n } from "@/i18n";
import { api, ApiError } from "@/lib/api";
import { cityLabel, useCities } from "@/lib/cities";
import { formatMoney, newIdempotencyKey } from "@/lib/format";
import type { Booking, Trip } from "@/lib/types";
import { useAuth } from "./auth-provider";
import { Alert, Button, Card, SelectInput } from "./ui";

export function BookingPanel({
  trip,
  initial,
  onBooked,
}: {
  trip: Trip;
  initial: { from?: string; to?: string; seats?: number };
  onBooked: () => void;
}) {
  const { t, locale, errorMessage } = useI18n();
  const { status, user, meta } = useAuth();
  const { byId } = useCities();
  const stops = trip.stops;
  const defaultFrom = stops.find((s) => s.id === initial.from)?.seq ?? 0;
  const defaultTo =
    stops.find((s) => s.id === initial.to && s.seq > defaultFrom)?.seq ??
    stops[stops.length - 1].seq;
  const [fromSeq, setFromSeq] = useState(defaultFrom);
  const [toSeq, setToSeq] = useState(defaultTo);
  const [seats, setSeats] = useState(
    Math.max(1, Math.min(7, initial.seats ?? 1)),
  );
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string>();
  const [done, setDone] = useState<Booking>();
  const keyRef = useRef<{ sig: string; key: string }>({ sig: "", key: "" });

  const legs = trip.segments.filter((s) => s.seq >= fromSeq && s.seq < toSeq);
  const maxSeats = useMemo(
    () => (legs.length ? Math.min(...legs.map((l) => l.seatsAvailable)) : 0),
    [legs],
  );
  const perSeat = legs.reduce((a, l) => a + l.priceMinor, 0);
  const effectiveSeats = Math.min(seats, Math.max(1, maxSeats));
  const stopLabel = (s: Trip["stops"][number]) =>
    `${cityLabel(byId.get(s.cityId), locale, s.city)} – ${s.name}`;

  // Who can/can't book, evaluated for display only; the server enforces every rule again.
  let blocker: string | undefined;
  if (trip.status !== "scheduled") blocker = t("book.cancelled");
  else if (status === "authed" && user?.id === trip.driver.id)
    blocker = t("book.own_trip");
  else if (meta && !meta.features.booking) blocker = t("book.disabled");
  else if (status === "authed" && user && !user.emailVerified)
    blocker = t("book.verify_required");
  else if (toSeq <= fromSeq) blocker = t("book.invalid_route");
  else if (maxSeats < 1) blocker = t("book.no_seats");

  async function submit() {
    setSubmitting(true);
    setError(undefined);
    const body = {
      fromStopId: stops[fromSeq].id,
      toStopId: stops[toSeq].id,
      seats: effectiveSeats,
    };
    // Same inputs => same Idempotency-Key, so a retry/double-click can never create two bookings.
    const sig = JSON.stringify(body);
    if (keyRef.current.sig !== sig)
      keyRef.current = { sig, key: newIdempotencyKey() };
    try {
      const b = await api<Booking>(`/trips/${trip.id}/bookings`, {
        method: "POST",
        body,
        headers: { "Idempotency-Key": keyRef.current.key },
      });
      setDone(b);
      onBooked();
    } catch (e) {
      setError(errorMessage(e));
      if (e instanceof ApiError && e.code === "seat_unavailable") onBooked();
    } finally {
      setSubmitting(false);
    }
  }

  if (done) {
    return (
      <Card className="space-y-4">
        <Alert kind="success">
          {done.status === "confirmed"
            ? t("book.success_confirmed")
            : t("book.success_pending")}
        </Alert>
        <Link
          href="/dashboard"
          className="inline-flex min-h-11 items-center rounded-lg bg-brand-600 px-4 text-sm font-semibold text-white hover:bg-brand-700"
        >
          {t("book.view_mine")}
        </Link>
      </Card>
    );
  }

  return (
    <Card className="space-y-4 lg:sticky lg:top-20">
      <h2 className="text-lg font-bold text-brand-900">{t("book.title")}</h2>
      <p className="text-sm text-gray-600">
        {trip.bookingMode === "instant"
          ? t("trip.mode_instant_desc")
          : t("trip.mode_approval_desc")}
      </p>

      <SelectInput
        id="bk-from"
        label={t("book.pickup")}
        value={fromSeq}
        onChange={(e) => {
          const v = Number(e.target.value);
          setFromSeq(v);
          if (toSeq <= v) setToSeq(Math.min(stops.length - 1, v + 1));
        }}
      >
        {stops.slice(0, -1).map((s) => (
          <option key={s.id} value={s.seq}>
            {stopLabel(s)}
          </option>
        ))}
      </SelectInput>
      <SelectInput
        id="bk-to"
        label={t("book.dropoff")}
        value={toSeq}
        onChange={(e) => setToSeq(Number(e.target.value))}
      >
        {stops
          .filter((s) => s.seq > fromSeq)
          .map((s) => (
            <option key={s.id} value={s.seq}>
              {stopLabel(s)}
            </option>
          ))}
      </SelectInput>
      <SelectInput
        id="bk-seats"
        label={t("book.seats")}
        value={effectiveSeats}
        onChange={(e) => setSeats(Number(e.target.value))}
        disabled={maxSeats < 1}
      >
        {Array.from({ length: Math.max(1, maxSeats) }, (_, i) => i + 1).map(
          (n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ),
        )}
      </SelectInput>

      <dl className="space-y-1 rounded-lg bg-sand-100 p-3 text-sm">
        <div className="flex justify-between">
          <dt>{t("book.per_seat")}</dt>
          <dd>{formatMoney(perSeat, locale, trip.currency)}</dd>
        </div>
        <div className="flex justify-between text-base font-bold text-brand-900">
          <dt>{t("book.total")}</dt>
          <dd>
            {formatMoney(perSeat * effectiveSeats, locale, trip.currency)}
          </dd>
        </div>
      </dl>
      <p className="text-xs text-gray-500">{t("book.no_payment")}</p>

      {error && <Alert kind="error">{error}</Alert>}
      {blocker && <Alert kind="warning">{blocker}</Alert>}

      {status === "anon" ? (
        <div className="space-y-2">
          <Alert kind="info">{t("book.login_required")}</Alert>
          <Link
            href={`/login?next=${encodeURIComponent(`/trips/${trip.id}`)}`}
            className="inline-flex min-h-11 w-full items-center justify-center rounded-lg bg-brand-600 px-4 text-sm font-semibold text-white hover:bg-brand-700"
          >
            {t("nav.login")}
          </Link>
        </div>
      ) : (
        <Button
          className="w-full"
          loading={submitting}
          disabled={!!blocker || status !== "authed"}
          onClick={submit}
        >
          {trip.bookingMode === "instant"
            ? t("book.submit")
            : t("book.submit_request")}
        </Button>
      )}
    </Card>
  );
}
