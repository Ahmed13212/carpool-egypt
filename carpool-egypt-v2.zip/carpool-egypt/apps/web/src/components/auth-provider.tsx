"use client";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { api, onTokenChange, refreshSession, setAccessToken } from "@/lib/api";
import type { Me, Meta } from "@/lib/types";

interface AuthCtx {
  status: "loading" | "anon" | "authed";
  user: Me | null;
  meta: Meta | null;
  login: (email: string, password: string) => Promise<Me>;
  logout: () => Promise<void>;
  reloadUser: () => Promise<void>;
  can: (permission: string) => boolean;
}
const Ctx = createContext<AuthCtx | null>(null);

/** Serialise refreshes across tabs: the server treats re-use of a rotated refresh token as theft and revokes every session. */
async function refreshAcrossTabs(): Promise<string | null> {
  if (typeof navigator !== "undefined" && navigator.locks) {
    return navigator.locks.request("masar-refresh", () => refreshSession());
  }
  return refreshSession();
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AuthCtx["status"]>("loading");
  const [user, setUser] = useState<Me | null>(null);
  const [meta, setMeta] = useState<Meta | null>(null);

  const loadMe = useCallback(async () => {
    const me = await api<Me>("/me");
    setUser(me);
    setStatus("authed");
    return me;
  }, []);

  useEffect(() => {
    let alive = true;
    api<Meta>("/meta", { auth: false })
      .then((m) => alive && setMeta(m))
      .catch(() => undefined);
    (async () => {
      const token = await refreshAcrossTabs();
      if (!alive) return;
      if (!token) {
        setStatus("anon");
        return;
      }
      try {
        await loadMe();
      } catch {
        if (alive) {
          setAccessToken(null);
          setStatus("anon");
        }
      }
    })();
    return () => {
      alive = false;
    };
  }, [loadMe]);

  // If the session dies mid-use (revoked, suspended, expired refresh) fall back to the signed-out state.
  useEffect(
    () =>
      onTokenChange((t) => {
        if (t === null) {
          setUser(null);
          setStatus((s) => (s === "loading" ? s : "anon"));
        }
      }),
    [],
  );

  const login = useCallback(
    async (email: string, password: string) => {
      const res = await api<{ accessToken: string }>("/auth/login", {
        method: "POST",
        body: { email, password },
        auth: false,
      });
      setAccessToken(res.accessToken);
      return loadMe();
    },
    [loadMe],
  );

  const logout = useCallback(async () => {
    try {
      await api("/auth/logout", {
        method: "POST",
        headers: { "X-Requested-With": "fetch" },
        auth: false,
      });
    } catch {
      /* cookie may already be gone */
    }
    setAccessToken(null);
    setUser(null);
    setStatus("anon");
  }, []);

  const value = useMemo<AuthCtx>(
    () => ({
      status,
      user,
      meta,
      login,
      logout,
      reloadUser: async () => {
        await loadMe();
      },
      can: (p) => !!user?.permissions.includes(p),
    }),
    [status, user, meta, login, logout, loadMe],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be used inside AuthProvider");
  return c;
}
