"use client";
import Link from "next/link";
import { useI18n } from "@/i18n";
import { cityLabel, useCities } from "@/lib/cities";
import {
  formatDate,
  formatDuration,
  formatMoney,
  formatTime,
} from "@/lib/format";
import type { SearchItem } from "@/lib/types";
import { Badge, Card } from "./ui";

export function TripCard({ item, seats }: { item: SearchItem; seats: number }) {
  const { t, locale } = useI18n();
  const { bySlug } = useCities();
  const minutes = Math.round(
    (new Date(item.to.arriveAt).getTime() -
      new Date(item.from.departAt).getTime()) /
      60000,
  );
  const href = `/trips/${item.tripId}?from=${item.from.stopId}&to=${item.to.stopId}&seats=${seats}`;
  return (
    <Card className="transition-shadow hover:shadow-md">
      <Link
        href={href}
        className="grid gap-4 sm:grid-cols-[1fr_auto] sm:items-center"
        aria-label={`${cityLabel(bySlug.get(item.from.city), locale, item.from.city)} → ${cityLabel(bySlug.get(item.to.city), locale, item.to.city)}`}
      >
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="flex flex-col items-center pt-1" aria-hidden>
              <span className="size-3 rounded-full border-2 border-brand-600" />
              <span className="h-9 w-0.5 bg-brand-600/30" />
              <span className="size-3 rounded-full bg-brand-600" />
            </div>
            <div className="space-y-4">
              <div>
                <p className="font-semibold text-gray-900">
                  {formatTime(item.from.departAt, locale)} ·{" "}
                  {cityLabel(
                    bySlug.get(item.from.city),
                    locale,
                    item.from.city,
                  )}
                </p>
                <p className="text-xs text-gray-500">
                  {item.from.name} · {formatDate(item.from.departAt, locale)}
                </p>
              </div>
              <div>
                <p className="font-semibold text-gray-900">
                  {formatTime(item.to.arriveAt, locale)} ·{" "}
                  {cityLabel(bySlug.get(item.to.city), locale, item.to.city)}
                </p>
                <p className="text-xs text-gray-500">
                  {item.to.name} · {formatDuration(minutes, locale)}
                </p>
              </div>
            </div>
          </div>
          <p className="text-sm text-gray-600">
            {item.driver.fullName} · {item.vehicle.make} {item.vehicle.model},{" "}
            {item.vehicle.color}
          </p>
        </div>
        <div className="flex flex-row items-center justify-between gap-2 sm:flex-col sm:items-end">
          <div className="sm:text-end">
            <p className="text-xl font-bold text-brand-700">
              {formatMoney(item.pricePerSeatMinor, locale, item.currency)}
            </p>
            <p className="text-xs text-gray-500">{t("results.per_seat")}</p>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Badge tone={item.bookingMode === "instant" ? "green" : "blue"}>
              {item.bookingMode === "instant"
                ? t("results.instant")
                : t("results.approval")}
            </Badge>
            <span className="text-xs text-gray-600">
              {item.seatsAvailable === 1
                ? t("results.seat_left")
                : t("results.seats_left", { n: item.seatsAvailable })}
            </span>
          </div>
        </div>
      </Link>
    </Card>
  );
}
