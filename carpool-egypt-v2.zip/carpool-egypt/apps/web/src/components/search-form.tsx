"use client";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { useI18n } from "@/i18n";
import { cityLabel, useCities } from "@/lib/cities";
import { Alert, Button, SelectInput, TextInput } from "./ui";

export interface SearchValues {
  from: string;
  to: string;
  date: string;
  seats: string;
}

export function SearchForm({ initial }: { initial?: Partial<SearchValues> }) {
  const { t, locale } = useI18n();
  const router = useRouter();
  const { cities, error: citiesError } = useCities();
  const [v, setV] = useState<SearchValues>({
    from: initial?.from ?? "",
    to: initial?.to ?? "",
    date: initial?.date ?? "",
    seats: initial?.seats ?? "1",
  });
  const [errors, setErrors] = useState<
    Partial<Record<keyof SearchValues, string>>
  >({});

  function submit(e: FormEvent) {
    e.preventDefault();
    const err: typeof errors = {};
    if (!v.from) err.from = t("search.select_city");
    if (!v.to) err.to = t("search.select_city");
    if (v.from && v.to && v.from === v.to) err.to = t("search.same_city");
    setErrors(err);
    if (Object.keys(err).length) return;
    const q = new URLSearchParams({ from: v.from, to: v.to, seats: v.seats });
    if (v.date) q.set("date", v.date);
    router.push(`/search?${q.toString()}`);
  }

  const options = (
    <>
      <option value="">{t("search.select_city")}</option>
      {cities.map((c) => (
        <option key={c.id} value={c.slug}>
          {cityLabel(c, locale)}
        </option>
      ))}
    </>
  );

  return (
    <form
      onSubmit={submit}
      noValidate
      className="grid gap-3 rounded-2xl bg-white p-4 shadow-md sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_8rem_auto] lg:items-end"
    >
      {citiesError != null && (
        <div className="sm:col-span-2 lg:col-span-5">
          <Alert kind="error">{t("search.cities_error")}</Alert>
        </div>
      )}
      <SelectInput
        id="sf-from"
        label={t("search.from")}
        value={v.from}
        error={errors.from}
        onChange={(e) => setV({ ...v, from: e.target.value })}
      >
        {options}
      </SelectInput>
      <SelectInput
        id="sf-to"
        label={t("search.to")}
        value={v.to}
        error={errors.to}
        onChange={(e) => setV({ ...v, to: e.target.value })}
      >
        {options}
      </SelectInput>
      <TextInput
        id="sf-date"
        type="date"
        label={t("search.date")}
        optional
        value={v.date}
        onChange={(e) => setV({ ...v, date: e.target.value })}
      />
      <SelectInput
        id="sf-seats"
        label={t("search.seats")}
        value={v.seats}
        onChange={(e) => setV({ ...v, seats: e.target.value })}
      >
        {[1, 2, 3, 4, 5, 6, 7].map((n) => (
          <option key={n} value={n}>
            {n}
          </option>
        ))}
      </SelectInput>
      <Button type="submit" className="lg:mb-0">
        {t("search.button")}
      </Button>
    </form>
  );
}
