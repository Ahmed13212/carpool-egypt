"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";
import { DevOutbox } from "@/components/dev-outbox";
import { Alert, Button, Card, PageSpinner, TextInput } from "@/components/ui";
import { useI18n } from "@/i18n";
import { api } from "@/lib/api";

function ResetForm() {
  const { t, errorMessage } = useI18n();
  const sp = useSearchParams();
  const [token, setToken] = useState(sp.get("token") ?? "");
  const [pw, setPw] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string>();
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (token.trim().length < 20) err.token = t("validation.required");
    if (pw.length < 10) err.pw = t("validation.password_min");
    setErrors(err);
    setFormError(undefined);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      await api("/auth/password-reset/confirm", {
        method: "POST",
        auth: false,
        body: { token: token.trim(), newPassword: pw },
      });
      setOk(true);
    } catch (e) {
      setFormError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="mx-auto max-w-md space-y-4">
      <h1 className="text-2xl font-bold text-brand-900">{t("reset.title")}</h1>
      {ok ? (
        <>
          <Alert kind="success">{t("reset.success")}</Alert>
          <Link className="text-brand-700 underline" href="/login">
            {t("nav.login")}
          </Link>
        </>
      ) : (
        <form onSubmit={submit} noValidate className="space-y-4">
          <DevOutbox
            email={sp.get("email") ?? ""}
            kind="password_reset"
            onToken={setToken}
          />
          {formError && <Alert kind="error">{formError}</Alert>}
          <TextInput
            id="token"
            label={t("reset.code")}
            value={token}
            error={errors.token}
            onChange={(e) => setToken(e.target.value)}
            dir="ltr"
          />
          <TextInput
            id="pw"
            type="password"
            autoComplete="new-password"
            label={t("reset.new_password")}
            hint={t("auth.password_hint")}
            value={pw}
            error={errors.pw}
            onChange={(e) => setPw(e.target.value)}
            dir="ltr"
          />
          <Button type="submit" className="w-full" loading={busy}>
            {t("reset.submit")}
          </Button>
        </form>
      )}
    </Card>
  );
}
export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<PageSpinner />}>
      <ResetForm />
    </Suspense>
  );
}
