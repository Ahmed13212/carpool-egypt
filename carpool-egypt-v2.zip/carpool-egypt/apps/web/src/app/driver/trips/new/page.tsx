"use client";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { useAuth } from "@/components/auth-provider";
import { RequireAuth } from "@/components/require-auth";
import {
  Alert,
  Button,
  Card,
  PageTitle,
  SelectInput,
  TextArea,
  TextInput,
} from "@/components/ui";
import { useQuery } from "@/hooks/use-query";
import { useI18n } from "@/i18n";
import { api } from "@/lib/api";
import { cityLabel, useCities } from "@/lib/cities";
import { cairoLocalToIso, egpToMinor } from "@/lib/format";
import type { Trip, Vehicle } from "@/lib/types";

interface StopForm {
  cityId: string;
  name: string;
  autoName: boolean;
  offset: string;
  lat: string;
  lng: string;
}
const blank = (offset = ""): StopForm => ({
  cityId: "",
  name: "",
  autoName: true,
  offset,
  lat: "",
  lng: "",
});

function TripForm() {
  const { t, locale, errorMessage } = useI18n();
  const { meta, can } = useAuth();
  const router = useRouter();
  const { cities, byId } = useCities();
  const vehicles = useQuery(
    (signal) => api<Vehicle[]>("/me/vehicles", { signal }),
    [],
  );
  const approved = (vehicles.data ?? []).filter(
    (v) => v.verificationStatus === "approved",
  );

  const [vehicleId, setVehicleId] = useState("");
  const [departure, setDeparture] = useState("");
  const [seats, setSeats] = useState("3");
  const [mode, setMode] = useState<"instant" | "approval">("approval");
  const [notes, setNotes] = useState("");
  const [stops, setStops] = useState<StopForm[]>([blank("0"), blank()]);
  const [prices, setPrices] = useState<string[]>([""]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string>();
  const [busy, setBusy] = useState(false);

  const vehicle = approved.find((v) => v.id === (vehicleId || approved[0]?.id));
  const maxSeats = vehicle ? Math.min(7, vehicle.seats - 1) : 7;

  const updateStop = (i: number, patch: Partial<StopForm>) =>
    setStops((s) => s.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const pickCity = (i: number, cityId: string) => {
    const c = byId.get(cityId);
    setStops((s) =>
      s.map((x, j) =>
        j === i
          ? { ...x, cityId, name: x.autoName ? cityLabel(c, locale) : x.name }
          : x,
      ),
    );
  };
  const addStop = () => {
    setStops((s) => [...s, blank()]);
    setPrices((p) => [...p, ""]);
  };
  const removeStop = (i: number) => {
    setStops((s) => s.filter((_, j) => j !== i));
    setPrices((p) => p.filter((_, j) => j !== Math.min(i, p.length - 1)));
  };

  async function submit(e: FormEvent) {
    e.preventDefault();
    const err: Record<string, string> = {};
    const veh = vehicle;
    if (!veh) err.vehicle = t("tf.no_vehicle");
    let departureIso = "";
    if (!departure) err.departure = t("validation.date_required");
    else {
      departureIso = cairoLocalToIso(departure);
      if (new Date(departureIso).getTime() < Date.now())
        err.departure = t("validation.date_future");
    }
    const n = Number(seats);
    if (!Number.isInteger(n) || n < 1 || n > maxSeats)
      err.seats = t("validation.seats_range");

    const seen = new Set<string>();
    let prev = -1;
    const payloadStops = stops.map((s, i) => {
      const city = byId.get(s.cityId);
      if (!city) err[`city${i}`] = t("validation.city_required");
      else if (seen.has(s.cityId))
        err[`city${i}`] = t("validation.cities_unique");
      seen.add(s.cityId);
      if (s.name.trim().length < 2) err[`name${i}`] = t("validation.name_min");
      const off = i === 0 ? 0 : Number(s.offset);
      if (i === 0 && s.offset !== "0" && s.offset !== "")
        err[`offset${i}`] = t("validation.first_offset");
      if (i > 0 && (s.offset === "" || !Number.isInteger(off) || off <= prev))
        err[`offset${i}`] = t("validation.offsets");
      prev = off;
      const lat = s.lat ? Number(s.lat) : city?.lat,
        lng = s.lng ? Number(s.lng) : city?.lng;
      return {
        cityId: s.cityId,
        name: s.name.trim(),
        lat: lat as number,
        lng: lng as number,
        offsetMinutes: off,
      };
    });
    const minor = prices.map((p, i) => {
      const m = egpToMinor(p);
      if (m === null) err[`price${i}`] = t("validation.price");
      return m as number;
    });

    setErrors(err);
    setFormError(undefined);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      const trip = await api<Trip>("/trips", {
        method: "POST",
        body: {
          vehicleId: veh!.id,
          departureAt: departureIso,
          seatsTotal: n,
          bookingMode: mode,
          notes: notes.trim() || undefined,
          stops: payloadStops,
          segmentPricesMinor: minor,
        },
      });
      router.replace(`/driver/trips/${trip.id}?published=1`);
    } catch (e) {
      setFormError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  const disabled = meta && !meta.features.tripPublishing;
  if (!can("trip:publish"))
    return <Alert kind="warning">{t("driver.need_approval")}</Alert>;

  return (
    <form onSubmit={submit} noValidate className="space-y-6">
      {disabled && <Alert kind="warning">{t("tf.disabled")}</Alert>}
      {formError && <Alert kind="error">{formError}</Alert>}

      <Card className="grid gap-4 sm:grid-cols-2">
        {vehicles.data && approved.length === 0 && (
          <div className="sm:col-span-2">
            <Alert kind="warning">{t("tf.no_vehicle")}</Alert>
          </div>
        )}
        <SelectInput
          id="vehicle"
          label={t("tf.vehicle")}
          value={vehicle?.id ?? ""}
          error={errors.vehicle}
          onChange={(e) => setVehicleId(e.target.value)}
        >
          {approved.map((v) => (
            <option key={v.id} value={v.id}>
              {v.make} {v.model} · {v.plateNumber}
            </option>
          ))}
        </SelectInput>
        <TextInput
          id="departure"
          type="datetime-local"
          label={t("tf.departure")}
          hint={t("common.cairo_time")}
          value={departure}
          error={errors.departure}
          onChange={(e) => setDeparture(e.target.value)}
          dir="ltr"
        />
        <TextInput
          id="seats"
          type="number"
          min={1}
          max={maxSeats}
          label={t("tf.seats")}
          value={seats}
          error={errors.seats}
          onChange={(e) => setSeats(e.target.value)}
        />
        <SelectInput
          id="mode"
          label={t("tf.mode")}
          value={mode}
          onChange={(e) => setMode(e.target.value as "instant" | "approval")}
        >
          <option value="approval">{t("tf.mode_approval")}</option>
          <option value="instant">{t("tf.mode_instant")}</option>
        </SelectInput>
        <div className="sm:col-span-2">
          <TextArea
            id="notes"
            label={t("tf.notes")}
            optional
            maxLength={500}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>
      </Card>

      <Card className="space-y-4">
        <div>
          <h2 className="text-lg font-bold text-brand-900">{t("tf.stops")}</h2>
          <p className="text-sm text-gray-600">{t("tf.stops_hint")}</p>
        </div>
        {stops.map((s, i) => (
          <fieldset
            key={i}
            className="space-y-3 rounded-xl border border-black/10 p-4"
          >
            <legend className="px-2 text-sm font-semibold text-brand-700">
              {t("tf.stop_n", { n: i + 1 })}
            </legend>
            <div className="grid gap-3 sm:grid-cols-3">
              <SelectInput
                id={`city${i}`}
                label={t("tf.stop_city")}
                value={s.cityId}
                error={errors[`city${i}`]}
                onChange={(e) => pickCity(i, e.target.value)}
              >
                <option value="">{t("search.select_city")}</option>
                {cities.map((c) => (
                  <option key={c.id} value={c.id}>
                    {cityLabel(c, locale)}
                  </option>
                ))}
              </SelectInput>
              <TextInput
                id={`name${i}`}
                label={t("tf.stop_name")}
                value={s.name}
                error={errors[`name${i}`]}
                onChange={(e) =>
                  updateStop(i, { name: e.target.value, autoName: false })
                }
              />
              <TextInput
                id={`offset${i}`}
                type="number"
                min={0}
                label={t("tf.stop_offset")}
                value={i === 0 ? "0" : s.offset}
                disabled={i === 0}
                error={errors[`offset${i}`]}
                onChange={(e) => updateStop(i, { offset: e.target.value })}
                dir="ltr"
              />
            </div>
            <details className="text-sm">
              <summary className="cursor-pointer text-brand-700">
                {t("tf.advanced")}
              </summary>
              <p className="my-2 text-xs text-gray-600">
                {t("tf.coords_note")}
              </p>
              <div className="grid gap-3 sm:grid-cols-2">
                <TextInput
                  id={`lat${i}`}
                  type="number"
                  step="any"
                  label={t("tf.lat")}
                  optional
                  value={s.lat}
                  onChange={(e) => updateStop(i, { lat: e.target.value })}
                  dir="ltr"
                />
                <TextInput
                  id={`lng${i}`}
                  type="number"
                  step="any"
                  label={t("tf.lng")}
                  optional
                  value={s.lng}
                  onChange={(e) => updateStop(i, { lng: e.target.value })}
                  dir="ltr"
                />
              </div>
            </details>
            {i >= 2 && (
              <Button
                type="button"
                variant="ghost"
                onClick={() => removeStop(i)}
              >
                {t("tf.remove_stop")}
              </Button>
            )}
          </fieldset>
        ))}
        {stops.length < 10 && (
          <Button type="button" variant="secondary" onClick={addStop}>
            {t("tf.add_stop")}
          </Button>
        )}
      </Card>

      <Card className="space-y-4">
        <div>
          <h2 className="text-lg font-bold text-brand-900">{t("tf.prices")}</h2>
          <p className="text-sm text-gray-600">{t("common.egp_hint")}</p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {prices.map((p, i) => (
            <TextInput
              key={i}
              id={`price${i}`}
              inputMode="decimal"
              label={t("trip.leg", {
                from: cityLabel(
                  byId.get(stops[i]?.cityId),
                  locale,
                  stops[i]?.name || `#${i + 1}`,
                ),
                to: cityLabel(
                  byId.get(stops[i + 1]?.cityId),
                  locale,
                  stops[i + 1]?.name || `#${i + 2}`,
                ),
              })}
              value={p}
              error={errors[`price${i}`]}
              onChange={(e) =>
                setPrices((arr) =>
                  arr.map((x, j) => (j === i ? e.target.value : x)),
                )
              }
              dir="ltr"
            />
          ))}
        </div>
      </Card>

      <Button
        type="submit"
        loading={busy}
        disabled={!!disabled || approved.length === 0}
      >
        {t("tf.publish")}
      </Button>
    </form>
  );
}

export default function NewTripPage() {
  const { t } = useI18n();
  return (
    <RequireAuth>
      <PageTitle>{t("tf.title")}</PageTitle>
      <TripForm />
    </RequireAuth>
  );
}
