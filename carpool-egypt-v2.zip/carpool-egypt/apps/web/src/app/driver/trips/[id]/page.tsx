"use client";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";
import { useAuth } from "@/components/auth-provider";
import { RequireAuth } from "@/components/require-auth";
import { BookingStatusBadge, TripStatusBadge } from "@/components/status";
import {
  Alert,
  Button,
  Card,
  EmptyState,
  Modal,
  PageSpinner,
  PageTitle,
  SelectInput,
  TextArea,
} from "@/components/ui";
import { useQuery } from "@/hooks/use-query";
import { useI18n } from "@/i18n";
import { ApiError, api } from "@/lib/api";
import { cityLabel, useCities } from "@/lib/cities";
import {
  formatDate,
  formatDateTime,
  formatMoney,
  formatTime,
} from "@/lib/format";
import type { Page, Trip, TripBooking } from "@/lib/types";

function Manage() {
  const { id } = useParams<{ id: string }>();
  const { t, locale, errorMessage } = useI18n();
  const { user } = useAuth();
  const router = useRouter();
  const published = useSearchParams().get("published") === "1";
  const { byId } = useCities();
  const trip = useQuery(
    (signal) => api<Trip>(`/trips/${id}`, { auth: false, signal }),
    [id],
  );
  const bookings = useQuery(
    (signal) =>
      api<Page<TripBooking>>(`/trips/${id}/bookings?pageSize=50`, { signal }),
    [id],
  );
  const [msg, setMsg] = useState<{ kind: "success" | "error"; text: string }>();
  const [rejectTarget, setRejectTarget] = useState<TripBooking>();
  const [rejectReason, setRejectReason] = useState("");
  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [busy, setBusy] = useState<string>();
  const [mode, setMode] = useState<"instant" | "approval" | "">("");
  const [notes, setNotes] = useState<string | null>(null);

  const refresh = () => {
    trip.reload();
    bookings.reload();
  };
  const act = async (key: string, fn: () => Promise<unknown>, ok: string) => {
    setBusy(key);
    setMsg(undefined);
    try {
      await fn();
      setMsg({ kind: "success", text: ok });
      refresh();
    } catch (e) {
      setMsg({ kind: "error", text: errorMessage(e) });
    } finally {
      setBusy(undefined);
    }
  };

  if (trip.loading && !trip.data) return <PageSpinner />;
  if (
    (trip.error instanceof ApiError && trip.error.status === 404) ||
    (trip.data && user && trip.data.driver.id !== user.id)
  )
    return <Alert kind="error">{t("trip.not_found")}</Alert>;
  if (trip.error != null)
    return <Alert kind="error">{errorMessage(trip.error)}</Alert>;
  const tr = trip.data;
  if (!tr) return null;
  const first = tr.stops[0],
    last = tr.stops[tr.stops.length - 1];
  const nm = (s: Trip["stops"][number]) =>
    cityLabel(byId.get(s.cityId), locale, s.city);
  const editable = tr.status === "scheduled";

  async function save(e: FormEvent) {
    e.preventDefault();
    const body: Record<string, unknown> = {};
    if (mode) body.bookingMode = mode;
    if (notes !== null) body.notes = notes.trim() || null;
    if (!Object.keys(body).length) return;
    await act(
      "save",
      () => api(`/trips/${id}`, { method: "PATCH", body }),
      t("tm.saved"),
    );
  }

  return (
    <div className="space-y-6">
      <PageTitle
        sub={`${formatDate(tr.departureAt, locale)} · ${formatTime(tr.departureAt, locale)}`}
      >
        {nm(first)} → {nm(last)}{" "}
        <span className="align-middle">
          <TripStatusBadge status={tr.status} />
        </span>
      </PageTitle>
      {published && <Alert kind="success">{t("tf.published")}</Alert>}
      {msg && <Alert kind={msg.kind}>{msg.text}</Alert>}

      <Card className="space-y-3">
        <h2 className="text-lg font-bold text-brand-900">{t("tm.bookings")}</h2>
        {bookings.loading && !bookings.data && <PageSpinner />}
        {bookings.error != null && (
          <Alert kind="error">{errorMessage(bookings.error)}</Alert>
        )}
        {bookings.data &&
          (bookings.data.items.length === 0 ? (
            <EmptyState title={t("tm.no_bookings")} />
          ) : (
            <ul className="divide-y divide-black/5">
              {bookings.data.items.map((b) => (
                <li
                  key={b.id}
                  className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm"
                >
                  <div>
                    <p className="font-semibold">
                      {b.passengerName} · {b.seats}{" "}
                      {b.seats === 1 ? t("common.seat") : t("common.seats")}
                    </p>
                    <p className="text-gray-600">
                      {nm(tr.stops[b.fromStopSeq])} →{" "}
                      {nm(tr.stops[b.toStopSeq])} ·{" "}
                      {formatMoney(b.priceTotalMinor, locale, b.currency)}
                    </p>
                    {b.status === "pending_approval" && b.expiresAt && (
                      <p className="text-xs text-amber-800">
                        {t("dash.expires", {
                          when: formatDateTime(b.expiresAt, locale),
                        })}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <BookingStatusBadge status={b.status} />
                    {b.status === "pending_approval" && editable && (
                      <>
                        <Button
                          loading={busy === `c${b.id}`}
                          onClick={() =>
                            act(
                              `c${b.id}`,
                              () =>
                                api(`/bookings/${b.id}/confirm`, {
                                  method: "POST",
                                }),
                              t("tm.confirmed_ok"),
                            )
                          }
                        >
                          {t("tm.confirm")}
                        </Button>
                        <Button
                          variant="danger"
                          onClick={() => {
                            setRejectTarget(b);
                            setRejectReason("");
                          }}
                        >
                          {t("tm.reject")}
                        </Button>
                      </>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          ))}
      </Card>

      {editable && (
        <Card>
          <h2 className="mb-1 text-lg font-bold text-brand-900">
            {t("tm.edit")}
          </h2>
          <p className="mb-3 text-sm text-gray-600">{t("tm.edit_note")}</p>
          <form onSubmit={save} className="space-y-3">
            <SelectInput
              id="mode"
              label={t("tf.mode")}
              value={mode || tr.bookingMode}
              onChange={(e) =>
                setMode(e.target.value as "instant" | "approval")
              }
            >
              <option value="approval">{t("tf.mode_approval")}</option>
              <option value="instant">{t("tf.mode_instant")}</option>
            </SelectInput>
            <TextArea
              id="notes"
              label={t("tf.notes")}
              optional
              maxLength={500}
              value={notes ?? tr.notes ?? ""}
              onChange={(e) => setNotes(e.target.value)}
            />
            <Button type="submit" loading={busy === "save"}>
              {t("common.save")}
            </Button>
          </form>
        </Card>
      )}

      {editable && (
        <div>
          <Button variant="danger" onClick={() => setCancelOpen(true)}>
            {t("tm.cancel_trip")}
          </Button>
        </div>
      )}

      <Modal
        open={!!rejectTarget}
        onClose={() => setRejectTarget(undefined)}
        title={t("tm.reject_title")}
      >
        <TextArea
          id="rej"
          label={t("common.reason")}
          optional
          maxLength={300}
          value={rejectReason}
          onChange={(e) => setRejectReason(e.target.value)}
        />
        <div className="flex justify-end gap-2">
          <Button
            variant="secondary"
            onClick={() => setRejectTarget(undefined)}
          >
            {t("common.cancel")}
          </Button>
          <Button
            variant="danger"
            loading={busy === "reject"}
            onClick={async () => {
              const b = rejectTarget!;
              await act(
                "reject",
                () =>
                  api(`/bookings/${b.id}/reject`, {
                    method: "POST",
                    body: rejectReason.trim()
                      ? { reason: rejectReason.trim() }
                      : {},
                  }),
                t("tm.rejected_ok"),
              );
              setRejectTarget(undefined);
            }}
          >
            {t("tm.reject")}
          </Button>
        </div>
      </Modal>

      <Modal
        open={cancelOpen}
        onClose={() => setCancelOpen(false)}
        title={t("tm.cancel_title")}
      >
        <p className="text-sm text-gray-700">{t("tm.cancel_text")}</p>
        <TextArea
          id="cr"
          label={t("common.reason")}
          optional
          maxLength={300}
          value={cancelReason}
          onChange={(e) => setCancelReason(e.target.value)}
        />
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setCancelOpen(false)}>
            {t("tm.keep")}
          </Button>
          <Button
            variant="danger"
            loading={busy === "cancel"}
            onClick={async () => {
              await act(
                "cancel",
                () =>
                  api(`/trips/${id}/cancel`, {
                    method: "POST",
                    body: cancelReason.trim()
                      ? { reason: cancelReason.trim() }
                      : {},
                  }),
                t("tm.cancelled_ok"),
              );
              setCancelOpen(false);
              router.refresh();
            }}
          >
            {t("tm.cancel_trip")}
          </Button>
        </div>
      </Modal>
    </div>
  );
}

export default function ManageTripPage() {
  return (
    <RequireAuth>
      <Suspense fallback={<PageSpinner />}>
        <Manage />
      </Suspense>
    </RequireAuth>
  );
}
