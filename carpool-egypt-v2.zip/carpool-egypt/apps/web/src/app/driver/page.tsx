"use client";
import Link from "next/link";
import { useState, type FormEvent } from "react";
import { useAuth } from "@/components/auth-provider";
import { RequireAuth } from "@/components/require-auth";
import { TripStatusBadge } from "@/components/status";
import {
  Alert,
  Badge,
  Button,
  Card,
  EmptyState,
  PageTitle,
  Skeleton,
  TextInput,
} from "@/components/ui";
import { useQuery } from "@/hooks/use-query";
import { useI18n } from "@/i18n";
import type { MsgKey } from "@/i18n/en";
import { api } from "@/lib/api";
import { formatDate, formatTime } from "@/lib/format";
import type { DriverStatus, MyTrip, Page, Vehicle } from "@/lib/types";

const vTone = {
  approved: "green",
  pending_review: "amber",
  rejected: "red",
  suspended: "red",
} as const;

function ApplyCard({ onDone }: { onDone: () => void }) {
  const { t, errorMessage } = useI18n();
  const { reloadUser, user } = useAuth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  async function apply() {
    setBusy(true);
    setError(undefined);
    try {
      await api("/drivers/apply", { method: "POST" });
      await reloadUser();
      onDone();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <Card className="space-y-3">
      <h2 className="text-lg font-bold text-brand-900">
        {t("driver.apply_title")}
      </h2>
      <p className="text-sm text-gray-700">{t("driver.apply_text")}</p>
      <Alert kind="info">{t("driver.docs_notice")}</Alert>
      {error && <Alert kind="error">{error}</Alert>}
      <Button loading={busy} onClick={apply} disabled={!user?.emailVerified}>
        {t("driver.apply_cta")}
      </Button>
      {!user?.emailVerified && (
        <p className="text-xs text-amber-800">{t("book.verify_required")}</p>
      )}
    </Card>
  );
}

function VehicleForm({ onAdded }: { onAdded: () => void }) {
  const { t, errorMessage } = useI18n();
  const [v, setV] = useState({
    make: "",
    model: "",
    color: "",
    seats: "5",
    plate: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<{ kind: "success" | "error"; text: string }>();
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) =>
    setV({ ...v, [k]: e.target.value });

  async function submit(e: FormEvent) {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (!v.make.trim()) err.make = t("validation.required");
    if (!v.model.trim()) err.model = t("validation.required");
    if (!v.color.trim()) err.color = t("validation.required");
    if (v.plate.trim().length < 3) err.plate = t("validation.plate");
    const seats = Number(v.seats);
    if (!Number.isInteger(seats) || seats < 2 || seats > 8)
      err.seats = t("validation.vehicle_seats");
    setErrors(err);
    setMsg(undefined);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      await api("/vehicles", {
        method: "POST",
        body: {
          make: v.make.trim(),
          model: v.model.trim(),
          color: v.color.trim(),
          seats,
          plateNumber: v.plate.trim(),
        },
      });
      setMsg({ kind: "success", text: t("driver.vehicle_added") });
      setV({ make: "", model: "", color: "", seats: "5", plate: "" });
      onAdded();
    } catch (e) {
      setMsg({ kind: "error", text: errorMessage(e) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} noValidate className="grid gap-3 sm:grid-cols-2">
      <h3 className="font-semibold sm:col-span-2">{t("driver.add_vehicle")}</h3>
      {msg && (
        <div className="sm:col-span-2">
          <Alert kind={msg.kind}>{msg.text}</Alert>
        </div>
      )}
      <TextInput
        id="v-make"
        label={t("driver.make")}
        value={v.make}
        error={errors.make}
        onChange={set("make")}
      />
      <TextInput
        id="v-model"
        label={t("driver.model")}
        value={v.model}
        error={errors.model}
        onChange={set("model")}
      />
      <TextInput
        id="v-color"
        label={t("driver.color")}
        value={v.color}
        error={errors.color}
        onChange={set("color")}
      />
      <TextInput
        id="v-seats"
        type="number"
        min={2}
        max={8}
        label={t("driver.vehicle_seats")}
        value={v.seats}
        error={errors.seats}
        onChange={set("seats")}
      />
      <TextInput
        id="v-plate"
        label={t("driver.plate")}
        value={v.plate}
        error={errors.plate}
        onChange={set("plate")}
      />
      <div className="flex items-end">
        <Button type="submit" loading={busy}>
          {t("driver.add_vehicle")}
        </Button>
      </div>
    </form>
  );
}

function DriverDashboard() {
  const { t, locale, errorMessage } = useI18n();
  const { can } = useAuth();
  const status = useQuery(
    (signal) => api<DriverStatus>("/me/driver", { signal }),
    [],
  );
  const hasDriverRole = can("vehicle:manage");
  const vehicles = useQuery(
    (signal) => api<Vehicle[]>("/me/vehicles", { signal }),
    [hasDriverRole],
    hasDriverRole,
  );
  const trips = useQuery(
    (signal) => api<Page<MyTrip>>("/me/trips?pageSize=20", { signal }),
    [],
  );
  const st = status.data?.verificationStatus ?? "not_submitted";
  const approvedVehicles = (vehicles.data ?? []).filter(
    (v) => v.verificationStatus === "approved",
  );
  const canPublish = can("trip:publish") && approvedVehicles.length > 0;

  return (
    <div className="space-y-6">
      <PageTitle>{t("driver.title")}</PageTitle>
      {status.loading && !status.data && <Skeleton className="h-28" />}
      {status.error != null && (
        <Alert kind="error">{errorMessage(status.error)}</Alert>
      )}

      {status.data &&
        (st === "not_submitted" ? (
          <ApplyCard
            onDone={() => {
              status.reload();
              vehicles.reload();
            }}
          />
        ) : (
          <Card className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-semibold">{t("driver.status_label")}:</h2>
              <Badge
                tone={
                  st === "approved"
                    ? "green"
                    : st === "pending_review"
                      ? "amber"
                      : "red"
                }
              >
                {t(`driver.status.${st}` as MsgKey)}
              </Badge>
            </div>
            <p className="text-sm text-gray-700">
              {st === "pending_review"
                ? t("driver.pending_text")
                : st === "approved"
                  ? t("driver.approved_text")
                  : t("driver.rejected_text")}
            </p>
            {status.data.rejectionReason && (
              <p className="text-sm text-red-800">
                {t("driver.rejection_reason", {
                  reason: status.data.rejectionReason,
                })}
              </p>
            )}
            {st !== "approved" && (
              <Alert kind="info">{t("driver.docs_notice")}</Alert>
            )}
            {st === "rejected" && <ApplyCard onDone={() => status.reload()} />}
          </Card>
        ))}

      {hasDriverRole && (
        <Card className="space-y-4">
          <h2 className="text-lg font-bold text-brand-900">
            {t("driver.vehicles")}
          </h2>
          {vehicles.loading && !vehicles.data && <Skeleton className="h-16" />}
          {vehicles.data &&
            (vehicles.data.length === 0 ? (
              <p className="text-sm text-gray-600">{t("driver.no_vehicles")}</p>
            ) : (
              <ul className="divide-y divide-black/5">
                {vehicles.data.map((v) => (
                  <li
                    key={v.id}
                    className="flex flex-wrap items-center justify-between gap-2 py-2 text-sm"
                  >
                    <span>
                      {v.make} {v.model} · {v.color} ·{" "}
                      <span dir="ltr">{v.plateNumber}</span> · {v.seats}{" "}
                      {t("common.seats")}
                    </span>
                    <Badge tone={vTone[v.verificationStatus]}>
                      {t(`vstatus.${v.verificationStatus}` as MsgKey)}
                    </Badge>
                  </li>
                ))}
              </ul>
            ))}
          <VehicleForm onAdded={vehicles.reload} />
        </Card>
      )}

      <Card className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-bold text-brand-900">
            {t("driver.trips")}
          </h2>
          {canPublish ? (
            <Link
              href="/driver/trips/new"
              className="inline-flex min-h-11 items-center rounded-lg bg-brand-600 px-4 text-sm font-semibold text-white hover:bg-brand-700"
            >
              {t("driver.new_trip")}
            </Link>
          ) : (
            <span className="text-xs text-gray-600">
              {t("driver.need_approval")}
            </span>
          )}
        </div>
        {trips.loading && !trips.data && <Skeleton className="h-16" />}
        {trips.error != null && (
          <Alert kind="error">{errorMessage(trips.error)}</Alert>
        )}
        {trips.data &&
          (trips.data.items.length === 0 ? (
            <EmptyState title={t("driver.no_trips")} />
          ) : (
            <ul className="divide-y divide-black/5">
              {trips.data.items.map((tr) => (
                <li
                  key={tr.id}
                  className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm"
                >
                  <span>
                    {formatDate(tr.departureAt, locale)} ·{" "}
                    {formatTime(tr.departureAt, locale)} · {tr.seatsTotal}{" "}
                    {t("common.seats")} ·{" "}
                    {t("driver.active_bookings", { n: tr.activeBookings })}
                  </span>
                  <span className="flex items-center gap-2">
                    <TripStatusBadge status={tr.status} />
                    <Link
                      className="font-semibold text-brand-700 underline"
                      href={`/driver/trips/${tr.id}`}
                    >
                      {t("driver.manage")}
                    </Link>
                  </span>
                </li>
              ))}
            </ul>
          ))}
      </Card>
    </div>
  );
}

export default function DriverPage() {
  return (
    <RequireAuth>
      <DriverDashboard />
    </RequireAuth>
  );
}
