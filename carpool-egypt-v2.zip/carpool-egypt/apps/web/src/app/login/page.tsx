"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";
import { useAuth } from "@/components/auth-provider";
import { Alert, Button, Card, PageSpinner, TextInput } from "@/components/ui";
import { useI18n } from "@/i18n";
import { isEmail, safeNext } from "@/lib/validators";

function LoginForm() {
  const { t, errorMessage } = useI18n();
  const { login } = useAuth();
  const router = useRouter();
  const next = safeNext(useSearchParams().get("next"));
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ email?: string; password?: string }>(
    {},
  );
  const [formError, setFormError] = useState<string>();
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const err: typeof errors = {};
    if (!isEmail(email)) err.email = t("validation.email");
    if (!password) err.password = t("validation.required");
    setErrors(err);
    setFormError(undefined);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      await login(email.trim(), password);
      router.replace(next);
    } catch (e) {
      setFormError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="mx-auto max-w-md">
      <h1 className="mb-4 text-2xl font-bold text-brand-900">
        {t("auth.login_title")}
      </h1>
      <form onSubmit={submit} noValidate className="space-y-4">
        {formError && <Alert kind="error">{formError}</Alert>}
        <TextInput
          id="email"
          type="email"
          autoComplete="email"
          label={t("auth.email")}
          value={email}
          error={errors.email}
          onChange={(e) => setEmail(e.target.value)}
          dir="ltr"
        />
        <TextInput
          id="password"
          type="password"
          autoComplete="current-password"
          label={t("auth.password")}
          value={password}
          error={errors.password}
          onChange={(e) => setPassword(e.target.value)}
          dir="ltr"
        />
        <Button type="submit" className="w-full" loading={busy}>
          {t("auth.login_cta")}
        </Button>
      </form>
      <div className="mt-4 space-y-1 text-sm">
        <p>
          <Link className="text-brand-700 underline" href="/forgot-password">
            {t("auth.forgot")}
          </Link>
        </p>
        <p>
          {t("auth.no_account")}{" "}
          <Link
            className="font-semibold text-brand-700 underline"
            href="/register"
          >
            {t("nav.register")}
          </Link>
        </p>
      </div>
    </Card>
  );
}
export default function LoginPage() {
  return (
    <Suspense fallback={<PageSpinner />}>
      <LoginForm />
    </Suspense>
  );
}
