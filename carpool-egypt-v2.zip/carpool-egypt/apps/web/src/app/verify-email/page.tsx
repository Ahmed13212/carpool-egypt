"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  Suspense,
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";
import { useAuth } from "@/components/auth-provider";
import { DevOutbox } from "@/components/dev-outbox";
import { Alert, Button, Card, PageSpinner, TextInput } from "@/components/ui";
import { useI18n } from "@/i18n";
import { api } from "@/lib/api";

function VerifyContent() {
  const { t, errorMessage } = useI18n();
  const { user, reloadUser, status } = useAuth();
  const sp = useSearchParams();
  const email = sp.get("email") ?? user?.email ?? "";
  const [token, setToken] = useState(sp.get("token") ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const [ok, setOk] = useState(false);
  const auto = useRef(false);

  const verify = useCallback(
    async (code: string) => {
      setBusy(true);
      setError(undefined);
      try {
        await api("/auth/verify-email", {
          method: "POST",
          body: { token: code.trim() },
          auth: false,
        });
        setOk(true);
        if (status === "authed") await reloadUser();
      } catch (e) {
        setError(errorMessage(e));
      } finally {
        setBusy(false);
      }
    },
    [errorMessage, reloadUser, status],
  );

  useEffect(() => {
    const fromLink = sp.get("token");
    if (fromLink && !auto.current) {
      auto.current = true;
      void verify(fromLink);
    }
  }, [sp, verify]);

  return (
    <Card className="mx-auto max-w-lg space-y-4">
      <h1 className="text-2xl font-bold text-brand-900">{t("verify.title")}</h1>
      {ok ? (
        <>
          <Alert kind="success">{t("verify.success")}</Alert>
          <Link
            href="/search"
            className="inline-flex min-h-11 items-center rounded-lg bg-brand-600 px-4 text-sm font-semibold text-white hover:bg-brand-700"
          >
            {t("verify.go")}
          </Link>
        </>
      ) : (
        <>
          <Alert kind="info">
            {t("verify.no_mail")} {t("verify.how")}
          </Alert>
          <DevOutbox
            email={email}
            kind="email_verification"
            onToken={(tok) => {
              setToken(tok);
              void verify(tok);
            }}
          />
          <form
            onSubmit={(e: FormEvent) => {
              e.preventDefault();
              if (token.trim()) void verify(token);
            }}
            className="space-y-3"
            noValidate
          >
            <TextInput
              id="token"
              label={t("verify.token")}
              value={token}
              onChange={(e) => setToken(e.target.value)}
              dir="ltr"
            />
            {error && <Alert kind="error">{error}</Alert>}
            <Button type="submit" loading={busy} disabled={!token.trim()}>
              {t("verify.submit")}
            </Button>
          </form>
        </>
      )}
    </Card>
  );
}
export default function VerifyEmailPage() {
  return (
    <Suspense fallback={<PageSpinner />}>
      <VerifyContent />
    </Suspense>
  );
}
