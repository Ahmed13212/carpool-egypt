"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { useAuth } from "@/components/auth-provider";
import { Alert, Button, Card, SelectInput, TextInput } from "@/components/ui";
import { useI18n } from "@/i18n";
import { api } from "@/lib/api";
import { isEmail } from "@/lib/validators";

export default function RegisterPage() {
  const { t, locale, errorMessage } = useI18n();
  const { login } = useAuth();
  const router = useRouter();
  const [v, setV] = useState({
    fullName: "",
    email: "",
    password: "",
    confirm: "",
    locale,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string>();
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) =>
    setV({ ...v, [k]: e.target.value });

  async function submit(e: FormEvent) {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (v.fullName.trim().length < 2) err.fullName = t("validation.name_min");
    if (!isEmail(v.email)) err.email = t("validation.email");
    if (v.password.length < 10) err.password = t("validation.password_min");
    if (v.confirm !== v.password) err.confirm = t("validation.password_match");
    setErrors(err);
    setFormError(undefined);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      const email = v.email.trim();
      await api("/auth/register", {
        method: "POST",
        auth: false,
        body: {
          email,
          password: v.password,
          fullName: v.fullName.trim(),
          locale: v.locale,
        },
      });
      await login(email, v.password);
      router.replace(`/verify-email?email=${encodeURIComponent(email)}`);
    } catch (e) {
      setFormError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="mx-auto max-w-md">
      <h1 className="mb-4 text-2xl font-bold text-brand-900">
        {t("auth.register_title")}
      </h1>
      <form onSubmit={submit} noValidate className="space-y-4">
        {formError && <Alert kind="error">{formError}</Alert>}
        <TextInput
          id="fullName"
          autoComplete="name"
          label={t("auth.full_name")}
          value={v.fullName}
          error={errors.fullName}
          onChange={set("fullName")}
        />
        <TextInput
          id="email"
          type="email"
          autoComplete="email"
          label={t("auth.email")}
          value={v.email}
          error={errors.email}
          onChange={set("email")}
          dir="ltr"
        />
        <TextInput
          id="password"
          type="password"
          autoComplete="new-password"
          label={t("auth.password")}
          hint={t("auth.password_hint")}
          value={v.password}
          error={errors.password}
          onChange={set("password")}
          dir="ltr"
        />
        <TextInput
          id="confirm"
          type="password"
          autoComplete="new-password"
          label={t("auth.confirm_password")}
          value={v.confirm}
          error={errors.confirm}
          onChange={set("confirm")}
          dir="ltr"
        />
        <SelectInput
          id="locale"
          label={t("auth.language")}
          value={v.locale}
          onChange={set("locale")}
        >
          <option value="ar">العربية</option>
          <option value="en">English</option>
        </SelectInput>
        <Button type="submit" className="w-full" loading={busy}>
          {t("auth.register_cta")}
        </Button>
      </form>
      <p className="mt-4 text-sm">
        {t("auth.have_account")}{" "}
        <Link className="font-semibold text-brand-700 underline" href="/login">
          {t("nav.login")}
        </Link>
      </p>
    </Card>
  );
}
