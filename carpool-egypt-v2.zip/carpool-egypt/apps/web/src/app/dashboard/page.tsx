"use client";
import Link from "next/link";
import { useState } from "react";
import { BookingStatusBadge, TripStatusBadge } from "@/components/status";
import { RequireAuth } from "@/components/require-auth";
import {
  Alert,
  Button,
  Card,
  EmptyState,
  Modal,
  PageTitle,
  Pagination,
  Skeleton,
  TextArea,
} from "@/components/ui";
import { useQuery } from "@/hooks/use-query";
import { useI18n } from "@/i18n";
import { api, qs } from "@/lib/api";
import { cityLabel, useCities } from "@/lib/cities";
import {
  formatDate,
  formatDateTime,
  formatMoney,
  formatTime,
} from "@/lib/format";
import type { MyBooking, Page } from "@/lib/types";

const CANCELLABLE = ["pending_approval", "awaiting_payment", "confirmed"];

function Bookings() {
  const { t, locale, errorMessage } = useI18n();
  const { bySlug } = useCities();
  const [page, setPage] = useState(1);
  const { data, error, loading, reload } = useQuery(
    (signal) =>
      api<Page<MyBooking>>(`/me/bookings${qs({ page, pageSize: 10 })}`, {
        signal,
      }),
    [page],
  );
  const [target, setTarget] = useState<MyBooking>();
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ kind: "success" | "error"; text: string }>();

  async function cancel() {
    if (!target) return;
    setBusy(true);
    try {
      await api(`/bookings/${target.id}/cancel`, {
        method: "POST",
        body: reason.trim() ? { reason: reason.trim() } : {},
      });
      setMsg({ kind: "success", text: t("dash.cancelled_ok") });
      setTarget(undefined);
      setReason("");
      reload();
    } catch (e) {
      setMsg({ kind: "error", text: errorMessage(e) });
      setTarget(undefined);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <PageTitle sub={t("dash.no_notifications")}>{t("dash.title")}</PageTitle>
      {msg && <Alert kind={msg.kind}>{msg.text}</Alert>}
      {loading && !data && (
        <div
          className="space-y-3"
          role="status"
          aria-label={t("common.loading")}
        >
          <Skeleton className="h-28" />
          <Skeleton className="h-28" />
        </div>
      )}
      {error != null && (
        <Alert kind="error">
          <div className="flex items-center justify-between gap-3">
            <span>{errorMessage(error)}</span>
            <Button variant="secondary" onClick={reload}>
              {t("common.retry")}
            </Button>
          </div>
        </Alert>
      )}
      {data &&
        (data.items.length === 0 ? (
          <EmptyState
            title={t("dash.empty_title")}
            text={t("dash.empty_text")}
            action={
              <Link
                href="/search"
                className="inline-flex min-h-11 items-center rounded-lg bg-brand-600 px-4 text-sm font-semibold text-white"
              >
                {t("dash.find")}
              </Link>
            }
          />
        ) : (
          <>
            <ul className="space-y-3">
              {data.items.map((b) => {
                const canCancel =
                  CANCELLABLE.includes(b.status) &&
                  b.tripStatus === "scheduled" &&
                  new Date(b.from.at).getTime() > Date.now();
                return (
                  <li key={b.id}>
                    <Card className="space-y-3">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <p className="text-lg font-semibold">
                            {cityLabel(
                              bySlug.get(b.from.city),
                              locale,
                              b.from.city,
                            )}{" "}
                            →{" "}
                            {cityLabel(
                              bySlug.get(b.to.city),
                              locale,
                              b.to.city,
                            )}
                          </p>
                          <p className="text-sm text-gray-600">
                            {formatDate(b.from.at, locale)} ·{" "}
                            {formatTime(b.from.at, locale)} —{" "}
                            {formatTime(b.to.at, locale)}
                          </p>
                          <p className="text-sm text-gray-600">
                            {b.from.name} → {b.to.name}
                          </p>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          <BookingStatusBadge status={b.status} />
                          {b.tripStatus === "cancelled" && (
                            <TripStatusBadge status="cancelled" />
                          )}
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                        <span>
                          {t("dash.driver")}: {b.driverName} ·{" "}
                          {b.seats === 1
                            ? t("dash.seat_count")
                            : t("dash.seats_count", { n: b.seats })}{" "}
                          ·{" "}
                          <strong>
                            {formatMoney(b.priceTotalMinor, locale, b.currency)}
                          </strong>
                        </span>
                        <span className="flex gap-2">
                          <Link
                            href={`/trips/${b.tripId}`}
                            className="inline-flex min-h-11 items-center rounded-lg border border-brand-600/30 px-3 font-semibold text-brand-700 hover:bg-brand-50"
                          >
                            {t("common.view")}
                          </Link>
                          {canCancel && (
                            <Button
                              variant="danger"
                              onClick={() => {
                                setTarget(b);
                                setMsg(undefined);
                              }}
                            >
                              {t("dash.cancel")}
                            </Button>
                          )}
                        </span>
                      </div>
                      {b.status === "pending_approval" && b.expiresAt && (
                        <p className="text-xs text-amber-800">
                          {t("dash.expires", {
                            when: formatDateTime(b.expiresAt, locale),
                          })}
                        </p>
                      )}
                    </Card>
                  </li>
                );
              })}
            </ul>
            <Pagination
              page={data.page}
              pages={Math.max(1, Math.ceil(data.total / data.pageSize))}
              onChange={setPage}
            />
          </>
        ))}

      <Modal
        open={!!target}
        onClose={() => setTarget(undefined)}
        title={t("dash.cancel_title")}
      >
        <p className="text-sm text-gray-700">{t("dash.cancel_text")}</p>
        <TextArea
          id="cancel-reason"
          label={t("dash.cancel_reason")}
          value={reason}
          maxLength={300}
          onChange={(e) => setReason(e.target.value)}
        />
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setTarget(undefined)}>
            {t("dash.keep")}
          </Button>
          <Button variant="danger" loading={busy} onClick={cancel}>
            {t("dash.cancel")}
          </Button>
        </div>
      </Modal>
    </div>
  );
}

export default function DashboardPage() {
  return (
    <RequireAuth>
      <Bookings />
    </RequireAuth>
  );
}
