"use client";
import { useState, type FormEvent, type ReactNode } from "react";
import { useAuth } from "@/components/auth-provider";
import { RequireAuth } from "@/components/require-auth";
import {
  Alert,
  Badge,
  Button,
  Card,
  EmptyState,
  Modal,
  PageSpinner,
  PageTitle,
  Pagination,
  SelectInput,
  Skeleton,
  TextArea,
  TextInput,
} from "@/components/ui";
import { useQuery } from "@/hooks/use-query";
import { useI18n } from "@/i18n";
import { en, type MsgKey } from "@/i18n/en";
import { api, qs } from "@/lib/api";
import { formatDateTime, formatNumber, formatPercent } from "@/lib/format";
import type {
  AdminUser,
  AuditLog,
  Dashboard,
  Page,
  VerificationQueue,
} from "@/lib/types";

type Notice = { kind: "success" | "error"; text: string } | undefined;

function Stat({ label, value }: { label: string; value: ReactNode }) {
  return (
    <Card>
      <p className="text-sm text-gray-600">{label}</p>
      <p className="mt-1 text-2xl font-bold text-brand-900">{value}</p>
    </Card>
  );
}

function Overview() {
  const { t, locale, errorMessage } = useI18n();
  const { data, error, loading, reload } = useQuery(
    (s) => api<Dashboard>("/admin/dashboard", { signal: s }),
    [],
  );
  if (loading && !data)
    return (
      <div className="grid gap-3 sm:grid-cols-3">
        <Skeleton />
        <Skeleton />
        <Skeleton />
      </div>
    );
  if (error != null)
    return (
      <Alert kind="error">
        {errorMessage(error)}{" "}
        <Button variant="secondary" onClick={reload}>
          {t("common.retry")}
        </Button>
      </Alert>
    );
  if (!data) return null;
  const n = (x: number) => formatNumber(x, locale);
  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-600">
        {t("admin.live")} ·{" "}
        {t("admin.generated", {
          when: formatDateTime(data.generatedAt, locale),
        })}
      </p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label={t("admin.stat.users")} value={n(data.users.total)} />
        <Stat
          label={t("admin.stat.suspended")}
          value={n(data.users.suspended)}
        />
        <Stat
          label={t("admin.stat.drivers_pending")}
          value={n(data.drivers.pendingReview)}
        />
        <Stat
          label={t("admin.stat.drivers_approved")}
          value={n(data.drivers.approved)}
        />
        <Stat
          label={t("admin.stat.vehicles_pending")}
          value={n(data.vehicles.pendingReview)}
        />
        <Stat
          label={t("admin.stat.trips_upcoming")}
          value={n(data.trips.upcoming)}
        />
        <Stat label={t("admin.stat.trips_total")} value={n(data.trips.total)} />
        <Stat
          label={t("admin.stat.bookings_total")}
          value={n(data.bookings.total)}
        />
      </div>
      <Card>
        <h3 className="mb-2 font-semibold">
          {t("admin.stat.cancel_rate")}:{" "}
          {formatPercent(data.bookings.cancellationRate, locale)}
        </h3>
        <p className="mb-2 text-sm text-gray-600">
          {t("admin.stat.by_status")}
        </p>
        <ul className="flex flex-wrap gap-2">
          {Object.entries(data.bookings.byStatus).map(([k, v]) => (
            <li key={k}>
              <Badge tone="gray">
                {`bstatus.${k}` in en ? t(`bstatus.${k}` as MsgKey) : k}: {n(v)}
              </Badge>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

function Verifications() {
  const { t, locale, errorMessage } = useI18n();
  const { data, error, loading, reload } = useQuery(
    (s) => api<VerificationQueue>("/admin/verifications", { signal: s }),
    [],
  );
  const [notice, setNotice] = useState<Notice>();
  const [reject, setReject] = useState<{
    type: "driver" | "vehicle";
    id: string;
  }>();
  const [reason, setReason] = useState("");
  const [reasonError, setReasonError] = useState<string>();
  const [busy, setBusy] = useState<string>();

  async function run(
    key: string,
    path: string,
    body?: unknown,
    ok = t("admin.approved_ok"),
  ) {
    setBusy(key);
    setNotice(undefined);
    try {
      await api(path, { method: "POST", body });
      setNotice({ kind: "success", text: ok });
      reload();
    } catch (e) {
      setNotice({ kind: "error", text: errorMessage(e) });
    } finally {
      setBusy(undefined);
    }
  }
  async function confirmReject() {
    if (!reject) return;
    if (reject.type === "driver" && reason.trim().length < 3) {
      setReasonError(t("validation.min_reason"));
      return;
    }
    setReasonError(undefined);
    const path =
      reject.type === "driver"
        ? `/admin/drivers/${reject.id}/reject`
        : `/admin/vehicles/${reject.id}/reject`;
    await run(
      `r${reject.id}`,
      path,
      reject.type === "driver" ? { reason: reason.trim() } : {},
      t("admin.rejected_ok"),
    );
    setReject(undefined);
    setReason("");
  }

  if (loading && !data) return <PageSpinner />;
  if (error != null) return <Alert kind="error">{errorMessage(error)}</Alert>;
  if (!data) return null;
  return (
    <div className="space-y-5">
      <Alert kind="warning">{t("admin.docs_notice")}</Alert>
      {notice && <Alert kind={notice.kind}>{notice.text}</Alert>}
      <Card className="space-y-3">
        <h3 className="font-semibold">{t("admin.drivers_waiting")}</h3>
        {data.drivers.length === 0 ? (
          <p className="text-sm text-gray-600">{t("admin.nothing_pending")}</p>
        ) : (
          <ul className="divide-y divide-black/5">
            {data.drivers.map((d) => (
              <li
                key={d.userId}
                className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm"
              >
                <span>
                  <strong>{d.fullName}</strong> ·{" "}
                  <span dir="ltr">{d.email}</span> ·{" "}
                  {formatDateTime(d.appliedAt, locale)}
                </span>
                <span className="flex gap-2">
                  <Button
                    loading={busy === `a${d.userId}`}
                    onClick={() =>
                      run(`a${d.userId}`, `/admin/drivers/${d.userId}/approve`)
                    }
                  >
                    {t("admin.approve")}
                  </Button>
                  <Button
                    variant="danger"
                    onClick={() => {
                      setReject({ type: "driver", id: d.userId });
                      setReason("");
                    }}
                  >
                    {t("admin.reject")}
                  </Button>
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Card className="space-y-3">
        <h3 className="font-semibold">{t("admin.vehicles_waiting")}</h3>
        {data.vehicles.length === 0 ? (
          <p className="text-sm text-gray-600">{t("admin.nothing_pending")}</p>
        ) : (
          <ul className="divide-y divide-black/5">
            {data.vehicles.map((v) => (
              <li
                key={v.id}
                className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm"
              >
                <span>
                  {v.make} {v.model} · {v.color} ·{" "}
                  <span dir="ltr">{v.plateNumber}</span> · {v.seats}{" "}
                  {t("common.seats")} · {v.ownerName}
                </span>
                <span className="flex gap-2">
                  <Button
                    loading={busy === `a${v.id}`}
                    onClick={() =>
                      run(`a${v.id}`, `/admin/vehicles/${v.id}/approve`)
                    }
                  >
                    {t("admin.approve")}
                  </Button>
                  <Button
                    variant="danger"
                    onClick={() => {
                      setReject({ type: "vehicle", id: v.id });
                      setReason("");
                    }}
                  >
                    {t("admin.reject")}
                  </Button>
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Modal
        open={!!reject}
        onClose={() => setReject(undefined)}
        title={t("admin.reject_title")}
      >
        <TextArea
          id="rej-reason"
          label={t("admin.reject_reason")}
          optional={reject?.type === "vehicle"}
          maxLength={300}
          value={reason}
          error={reasonError}
          onChange={(e) => setReason(e.target.value)}
        />
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setReject(undefined)}>
            {t("common.cancel")}
          </Button>
          <Button
            variant="danger"
            loading={!!busy && busy.startsWith("r")}
            onClick={confirmReject}
          >
            {t("admin.reject")}
          </Button>
        </div>
      </Modal>
    </div>
  );
}

const GRANTABLE = [
  "support_agent",
  "verification_reviewer",
  "finance_operator",
  "administrator",
] as const;

function Users() {
  const { t, locale, errorMessage } = useI18n();
  const { can, user: me } = useAuth();
  const [q, setQ] = useState("");
  const [applied, setApplied] = useState("");
  const [page, setPage] = useState(1);
  const { data, error, loading, reload } = useQuery(
    (s) =>
      api<Page<AdminUser>>(
        `/admin/users${qs({ q: applied, page, pageSize: 15 })}`,
        { signal: s },
      ),
    [applied, page],
  );
  const [notice, setNotice] = useState<Notice>();
  const [suspend, setSuspend] = useState<AdminUser>();
  const [reason, setReason] = useState("");
  const [reasonError, setReasonError] = useState<string>();
  const [roles, setRoles] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string>();

  async function run(key: string, fn: () => Promise<unknown>, ok: string) {
    setBusy(key);
    setNotice(undefined);
    try {
      await fn();
      setNotice({ kind: "success", text: ok });
      reload();
    } catch (e) {
      setNotice({ kind: "error", text: errorMessage(e) });
    } finally {
      setBusy(undefined);
    }
  }

  return (
    <div className="space-y-4">
      <form
        onSubmit={(e: FormEvent) => {
          e.preventDefault();
          setPage(1);
          setApplied(q.trim());
        }}
        className="flex flex-wrap items-end gap-3"
        role="search"
      >
        <div className="min-w-64 flex-1">
          <TextInput
            id="user-q"
            label={t("admin.users_search")}
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <Button type="submit">{t("common.search")}</Button>
      </form>
      {notice && <Alert kind={notice.kind}>{notice.text}</Alert>}
      {loading && !data && <PageSpinner />}
      {error != null && <Alert kind="error">{errorMessage(error)}</Alert>}
      {data &&
        (data.items.length === 0 ? (
          <EmptyState title={t("admin.no_users")} />
        ) : (
          <>
            <ul className="space-y-3">
              {data.items.map((u) => (
                <li key={u.id}>
                  <Card className="space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <p className="font-semibold">{u.fullName}</p>
                        <p className="text-sm text-gray-600" dir="ltr">
                          {u.email}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        <Badge tone={u.status === "active" ? "green" : "red"}>
                          {u.status}
                        </Badge>
                        {u.roles.map((r) => (
                          <Badge key={r} tone="blue">
                            {r}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      {u.id !== me?.id &&
                        can("users:suspend") &&
                        u.status === "active" && (
                          <Button
                            variant="danger"
                            onClick={() => {
                              setSuspend(u);
                              setReason("");
                            }}
                          >
                            {t("admin.suspend")}
                          </Button>
                        )}
                      {can("users:reinstate") && u.status === "suspended" && (
                        <Button
                          loading={busy === u.id}
                          onClick={() =>
                            run(
                              u.id,
                              () =>
                                api(`/admin/users/${u.id}/reinstate`, {
                                  method: "POST",
                                }),
                              t("admin.reinstated_ok"),
                            )
                          }
                        >
                          {t("admin.reinstate")}
                        </Button>
                      )}
                      {can("roles:assign") && (
                        <span className="flex items-end gap-2">
                          <SelectInput
                            id={`role-${u.id}`}
                            label={t("admin.grant_role")}
                            value={roles[u.id] ?? GRANTABLE[0]}
                            onChange={(e) =>
                              setRoles({ ...roles, [u.id]: e.target.value })
                            }
                          >
                            {GRANTABLE.map((r) => (
                              <option key={r} value={r}>
                                {t(`role.${r}` as MsgKey)}
                              </option>
                            ))}
                          </SelectInput>
                          <Button
                            variant="secondary"
                            loading={busy === `g${u.id}`}
                            onClick={() =>
                              run(
                                `g${u.id}`,
                                () =>
                                  api(`/admin/users/${u.id}/roles`, {
                                    method: "POST",
                                    body: { role: roles[u.id] ?? GRANTABLE[0] },
                                  }),
                                t("admin.role_granted"),
                              )
                            }
                          >
                            {t("common.confirm")}
                          </Button>
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500">
                      {formatDateTime(u.createdAt, locale)}
                    </p>
                  </Card>
                </li>
              ))}
            </ul>
            <Pagination
              page={data.page}
              pages={Math.max(1, Math.ceil(data.total / data.pageSize))}
              onChange={setPage}
            />
          </>
        ))}
      <Modal
        open={!!suspend}
        onClose={() => setSuspend(undefined)}
        title={t("admin.suspend_title")}
      >
        <p className="text-sm text-gray-700">
          {suspend?.fullName} — {t("admin.suspend_text")}
        </p>
        <TextArea
          id="sus-reason"
          label={t("common.reason")}
          maxLength={300}
          value={reason}
          error={reasonError}
          onChange={(e) => setReason(e.target.value)}
        />
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setSuspend(undefined)}>
            {t("common.cancel")}
          </Button>
          <Button
            variant="danger"
            loading={busy === "suspend"}
            onClick={async () => {
              if (reason.trim().length < 3) {
                setReasonError(t("validation.min_reason"));
                return;
              }
              setReasonError(undefined);
              const u = suspend!;
              await run(
                "suspend",
                () =>
                  api(`/admin/users/${u.id}/suspend`, {
                    method: "POST",
                    body: { reason: reason.trim() },
                  }),
                t("admin.suspended_ok"),
              );
              setSuspend(undefined);
            }}
          >
            {t("admin.suspend")}
          </Button>
        </div>
      </Modal>
    </div>
  );
}

function Audit() {
  const { t, locale, errorMessage } = useI18n();
  const [action, setAction] = useState("");
  const [applied, setApplied] = useState("");
  const [page, setPage] = useState(1);
  const { data, error, loading } = useQuery(
    (s) =>
      api<Page<AuditLog>>(
        `/admin/audit-logs${qs({ action: applied, page, pageSize: 20 })}`,
        { signal: s },
      ),
    [applied, page],
  );
  return (
    <div className="space-y-4">
      <form
        onSubmit={(e: FormEvent) => {
          e.preventDefault();
          setPage(1);
          setApplied(action.trim());
        }}
        className="flex flex-wrap items-end gap-3"
      >
        <div className="min-w-64 flex-1">
          <TextInput
            id="audit-q"
            label={t("admin.audit_filter")}
            value={action}
            onChange={(e) => setAction(e.target.value)}
            dir="ltr"
          />
        </div>
        <Button type="submit">{t("common.search")}</Button>
      </form>
      {loading && !data && <PageSpinner />}
      {error != null && <Alert kind="error">{errorMessage(error)}</Alert>}
      {data &&
        (data.items.length === 0 ? (
          <EmptyState title={t("admin.no_audit")} />
        ) : (
          <>
            <div className="overflow-x-auto rounded-2xl border border-black/5 bg-white">
              <table className="w-full min-w-[40rem] text-start text-sm">
                <thead className="bg-sand-100 text-start">
                  <tr>
                    {[
                      t("admin.when"),
                      t("admin.action"),
                      t("admin.actor"),
                      t("admin.target"),
                    ].map((h) => (
                      <th
                        key={h}
                        scope="col"
                        className="p-3 text-start font-semibold"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-black/5">
                  {data.items.map((l) => (
                    <tr key={l.id}>
                      <td className="p-3 whitespace-nowrap">
                        {formatDateTime(l.createdAt, locale)}
                      </td>
                      <td className="p-3 font-mono text-xs" dir="ltr">
                        {l.action}
                      </td>
                      <td className="p-3 font-mono text-xs" dir="ltr">
                        {l.actorId?.slice(0, 8) ?? "—"}
                      </td>
                      <td className="p-3 font-mono text-xs" dir="ltr">
                        {l.targetType}:{l.targetId?.slice(0, 8) ?? "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination
              page={data.page}
              pages={Math.max(1, Math.ceil(data.total / data.pageSize))}
              onChange={setPage}
            />
          </>
        ))}
    </div>
  );
}

const BOOL_SETTINGS = [
  "trip_publishing_enabled",
  "booking_enabled",
  "payments_enabled",
  "require_driver_approval",
] as const;
const NUM_SETTINGS = [
  "booking_approval_timeout_minutes",
  "payment_hold_minutes",
  "max_segment_price_minor",
  "min_booking_lead_minutes",
] as const;

function Settings() {
  const { t, errorMessage } = useI18n();
  const { data, error, loading, reload } = useQuery(
    (s) => api<Record<string, unknown>>("/admin/settings", { signal: s }),
    [],
  );
  const [notice, setNotice] = useState<Notice>();
  const [confirm, setConfirm] = useState<{ key: string; value: boolean }>();
  const [nums, setNums] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  async function save(key: string, value: unknown) {
    setBusy(true);
    setNotice(undefined);
    try {
      await api(`/admin/settings/${key}`, { method: "PUT", body: { value } });
      setNotice({ kind: "success", text: t("admin.setting_saved") });
      reload();
    } catch (e) {
      setNotice({ kind: "error", text: errorMessage(e) });
    } finally {
      setBusy(false);
      setConfirm(undefined);
    }
  }

  if (loading && !data) return <PageSpinner />;
  if (error != null) return <Alert kind="error">{errorMessage(error)}</Alert>;
  if (!data) return null;
  return (
    <div className="space-y-4">
      <Alert kind="warning">{t("admin.settings_warn")}</Alert>
      {notice && <Alert kind={notice.kind}>{notice.text}</Alert>}
      <Card className="divide-y divide-black/5 !p-0">
        {BOOL_SETTINGS.map((k) => {
          const on = data[k] === true;
          const locked = k === "payments_enabled";
          return (
            <div
              key={k}
              className="flex flex-wrap items-center justify-between gap-3 p-4"
            >
              <div>
                <p className="font-medium">
                  {t(`admin.setting.${k}` as MsgKey)}
                </p>
                {locked && (
                  <p className="text-xs text-gray-600">
                    {t("admin.payments_locked")}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-3">
                <Badge tone={on ? "green" : "gray"}>
                  {on ? t("admin.on") : t("admin.off")}
                </Badge>
                <Button
                  variant="secondary"
                  disabled={locked}
                  onClick={() => setConfirm({ key: k, value: !on })}
                >
                  {on ? t("admin.off") : t("admin.on")}
                </Button>
              </div>
            </div>
          );
        })}
      </Card>
      <Card className="grid gap-4 sm:grid-cols-2">
        {NUM_SETTINGS.map((k) => (
          <div key={k} className="flex items-end gap-2">
            <div className="flex-1">
              <TextInput
                id={k}
                type="number"
                min={0}
                label={t(`admin.setting.${k}` as MsgKey)}
                value={nums[k] ?? String(data[k] ?? "")}
                onChange={(e) => setNums({ ...nums, [k]: e.target.value })}
                dir="ltr"
              />
            </div>
            <Button
              variant="secondary"
              disabled={busy || !(k in nums)}
              onClick={() => save(k, Number(nums[k]))}
            >
              {t("common.save")}
            </Button>
          </div>
        ))}
      </Card>
      <Modal
        open={!!confirm}
        onClose={() => setConfirm(undefined)}
        title={t("admin.setting_confirm_title")}
      >
        <p className="text-sm">
          {confirm && t(`admin.setting.${confirm.key}` as MsgKey)} →{" "}
          <strong>{confirm?.value ? t("admin.on") : t("admin.off")}</strong>
        </p>
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setConfirm(undefined)}>
            {t("common.cancel")}
          </Button>
          <Button
            loading={busy}
            onClick={() => confirm && save(confirm.key, confirm.value)}
          >
            {t("common.confirm")}
          </Button>
        </div>
      </Modal>
    </div>
  );
}

function AdminArea() {
  const { t } = useI18n();
  const { can } = useAuth();
  const tabs = [
    {
      id: "overview",
      label: t("admin.tab.overview"),
      show: can("admin:dashboard:read"),
      el: <Overview />,
    },
    {
      id: "verifications",
      label: t("admin.tab.verifications"),
      show: can("verification:review"),
      el: <Verifications />,
    },
    {
      id: "users",
      label: t("admin.tab.users"),
      show: can("users:read"),
      el: <Users />,
    },
    {
      id: "audit",
      label: t("admin.tab.audit"),
      show: can("audit:read"),
      el: <Audit />,
    },
    {
      id: "settings",
      label: t("admin.tab.settings"),
      show: can("settings:write"),
      el: <Settings />,
    },
  ].filter((x) => x.show);
  const [active, setActive] = useState(tabs[0]?.id);
  const current = tabs.find((x) => x.id === active) ?? tabs[0];
  return (
    <div className="space-y-5">
      <PageTitle>{t("admin.title")}</PageTitle>
      <div
        role="tablist"
        aria-label={t("admin.title")}
        className="flex gap-1 overflow-x-auto border-b border-black/10"
      >
        {tabs.map((x) => (
          <button
            key={x.id}
            role="tab"
            id={`tab-${x.id}`}
            aria-selected={current?.id === x.id}
            aria-controls={`panel-${x.id}`}
            onClick={() => setActive(x.id)}
            className={`min-h-11 whitespace-nowrap border-b-2 px-4 text-sm font-semibold ${current?.id === x.id ? "border-brand-600 text-brand-700" : "border-transparent text-gray-600 hover:text-brand-700"}`}
          >
            {x.label}
          </button>
        ))}
      </div>
      {current && (
        <div
          role="tabpanel"
          id={`panel-${current.id}`}
          aria-labelledby={`tab-${current.id}`}
        >
          {current.el}
        </div>
      )}
    </div>
  );
}

export default function AdminPage() {
  return (
    <RequireAuth permission="admin:dashboard:read">
      <AdminArea />
    </RequireAuth>
  );
}
