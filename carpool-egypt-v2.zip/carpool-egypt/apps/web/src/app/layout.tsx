import type { Metadata, Viewport } from "next";
import { cookies } from "next/headers";
import type { ReactNode } from "react";
import { AuthProvider } from "@/components/auth-provider";
import { Banners, Footer } from "@/components/banners";
import { Header } from "@/components/header";
import { I18nProvider } from "@/i18n";
import { LOCALE_COOKIE } from "@/i18n/config";
import type { Locale } from "@/lib/format";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Masar · مسار", template: "%s · Masar" },
  description:
    "Ride sharing between Egyptian cities / مشاركة الرحلات بين المدن المصرية",
};
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0b7f63",
};

export default async function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  const c = (await cookies()).get(LOCALE_COOKIE)?.value;
  const locale: Locale = c === "en" ? "en" : "ar"; // Arabic is the default
  return (
    <html lang={locale} dir={locale === "ar" ? "rtl" : "ltr"}>
      <body className="min-h-screen antialiased">
        <I18nProvider initialLocale={locale}>
          <AuthProvider>
            <a href="#main" className="skip-link">
              {locale === "ar"
                ? "تخطَّ إلى المحتوى الرئيسي"
                : "Skip to main content"}
            </a>
            <Header />
            <Banners />
            <main id="main" className="mx-auto max-w-6xl px-4 py-6">
              {children}
            </main>
            <Footer />
          </AuthProvider>
        </I18nProvider>
      </body>
    </html>
  );
}
