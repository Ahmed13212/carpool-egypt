"use client";
import Link from "next/link";
import { EmptyState } from "@/components/ui";
import { useI18n } from "@/i18n";

export default function NotFound() {
  const { t } = useI18n();
  return (
    <EmptyState
      title={t("errors.not_found")}
      action={
        <Link
          href="/"
          className="inline-flex min-h-11 items-center rounded-lg bg-brand-600 px-4 text-sm font-semibold text-white"
        >
          {t("app.name")}
        </Link>
      }
    />
  );
}
