"use client";
import { SearchForm } from "@/components/search-form";
import { Card } from "@/components/ui";
import { useI18n } from "@/i18n";

export default function HomePage() {
  const { t } = useI18n();
  const steps = [
    { t: t("home.step1_t"), d: t("home.step1_d") },
    { t: t("home.step2_t"), d: t("home.step2_d") },
    { t: t("home.step3_t"), d: t("home.step3_d") },
  ];
  const why = [
    { t: t("home.why1_t"), d: t("home.why1_d") },
    { t: t("home.why2_t"), d: t("home.why2_d") },
    { t: t("home.why3_t"), d: t("home.why3_d") },
  ];
  return (
    <div className="space-y-14">
      <section className="rounded-3xl bg-gradient-to-br from-brand-700 to-brand-900 px-5 py-10 text-white sm:px-10 sm:py-14">
        <h1 className="max-w-2xl text-3xl font-extrabold leading-tight sm:text-5xl">
          {t("home.title")}
        </h1>
        <p className="mt-4 max-w-2xl text-brand-100 sm:text-lg">
          {t("home.subtitle")}
        </p>
        <div className="mt-8 text-gray-900">
          <SearchForm />
        </div>
      </section>

      <section aria-labelledby="how">
        <h2 id="how" className="mb-6 text-2xl font-bold text-brand-900">
          {t("home.how_title")}
        </h2>
        <ol className="grid gap-4 sm:grid-cols-3">
          {steps.map((s, i) => (
            <li key={s.t}>
              <Card className="h-full">
                <span className="mb-3 grid size-9 place-items-center rounded-full bg-brand-100 font-bold text-brand-700">
                  {i + 1}
                </span>
                <h3 className="font-semibold text-gray-900">{s.t}</h3>
                <p className="mt-1 text-sm text-gray-600">{s.d}</p>
              </Card>
            </li>
          ))}
        </ol>
      </section>

      <section aria-labelledby="why">
        <h2 id="why" className="mb-6 text-2xl font-bold text-brand-900">
          {t("home.why_title")}
        </h2>
        <ul className="grid gap-4 sm:grid-cols-3">
          {why.map((w) => (
            <li key={w.t}>
              <Card className="h-full bg-sand-100">
                <h3 className="font-semibold text-gray-900">{w.t}</h3>
                <p className="mt-1 text-sm text-gray-700">{w.d}</p>
              </Card>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
