"use client";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { useAuth } from "@/components/auth-provider";
import { RequireAuth } from "@/components/require-auth";
import {
  Alert,
  Badge,
  Button,
  Card,
  PageTitle,
  SelectInput,
  TextInput,
} from "@/components/ui";
import { useI18n } from "@/i18n";
import { api } from "@/lib/api";
import { isPhone } from "@/lib/validators";
import { en, type MsgKey } from "@/i18n/en";

function ProfileForm() {
  const { t, errorMessage, setLocale } = useI18n();
  const roleLabel = (r: string) =>
    `role.${r}` in en ? t(`role.${r}` as MsgKey) : r;
  const { user, reloadUser } = useAuth();
  const [v, setV] = useState({
    fullName: user?.fullName ?? "",
    phone: user?.phone ?? "",
    locale: user?.locale ?? "ar",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<{ kind: "success" | "error"; text: string }>();
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (v.fullName.trim().length < 2) err.fullName = t("validation.name_min");
    if (v.phone && !isPhone(v.phone)) err.phone = t("validation.phone");
    setErrors(err);
    setMsg(undefined);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      await api("/me", {
        method: "PATCH",
        body: {
          fullName: v.fullName.trim(),
          phone: v.phone || null,
          locale: v.locale,
        },
      });
      await reloadUser();
      setLocale(v.locale as "ar" | "en");
      setMsg({ kind: "success", text: t("profile.saved") });
    } catch (e) {
      setMsg({ kind: "error", text: errorMessage(e) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <span dir="ltr" className="text-sm text-gray-700">
          {user?.email}
        </span>
        <Badge tone={user?.emailVerified ? "green" : "amber"}>
          {user?.emailVerified
            ? t("profile.email_verified")
            : t("profile.email_unverified")}
        </Badge>
        {user?.roles.map((r) => (
          <Badge key={r} tone="blue">
            {roleLabel(r)}
          </Badge>
        ))}
      </div>
      <form onSubmit={submit} noValidate className="space-y-4">
        {msg && <Alert kind={msg.kind}>{msg.text}</Alert>}
        <TextInput
          id="fullName"
          label={t("auth.full_name")}
          value={v.fullName}
          error={errors.fullName}
          onChange={(e) => setV({ ...v, fullName: e.target.value })}
        />
        <TextInput
          id="phone"
          type="tel"
          label={t("profile.phone")}
          optional
          value={v.phone}
          error={errors.phone}
          onChange={(e) => setV({ ...v, phone: e.target.value })}
          dir="ltr"
        />
        <SelectInput
          id="locale"
          label={t("auth.language")}
          value={v.locale}
          onChange={(e) =>
            setV({ ...v, locale: e.target.value as "ar" | "en" })
          }
        >
          <option value="ar">العربية</option>
          <option value="en">English</option>
        </SelectInput>
        <Button type="submit" loading={busy}>
          {t("common.save")}
        </Button>
      </form>
    </Card>
  );
}

function PasswordForm() {
  const { t, errorMessage } = useI18n();
  const { logout } = useAuth();
  const router = useRouter();
  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (!cur) err.cur = t("validation.required");
    if (next.length < 10) err.next = t("validation.password_min");
    setErrors(err);
    setError(undefined);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      await api("/auth/change-password", {
        method: "POST",
        body: { currentPassword: cur, newPassword: next },
      });
      await logout(); // the server revoked every session
      router.replace("/login");
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card>
      <h2 className="mb-4 text-lg font-bold text-brand-900">
        {t("profile.password_title")}
      </h2>
      <form onSubmit={submit} noValidate className="space-y-4">
        {error && <Alert kind="error">{error}</Alert>}
        <TextInput
          id="cur"
          type="password"
          autoComplete="current-password"
          label={t("profile.current_password")}
          value={cur}
          error={errors.cur}
          onChange={(e) => setCur(e.target.value)}
          dir="ltr"
        />
        <TextInput
          id="next"
          type="password"
          autoComplete="new-password"
          label={t("profile.new_password")}
          hint={t("auth.password_hint")}
          value={next}
          error={errors.next}
          onChange={(e) => setNext(e.target.value)}
          dir="ltr"
        />
        <Button type="submit" variant="secondary" loading={busy}>
          {t("profile.password_title")}
        </Button>
      </form>
    </Card>
  );
}

export default function ProfilePage() {
  const { t } = useI18n();
  return (
    <RequireAuth>
      <div className="mx-auto max-w-xl space-y-6">
        <PageTitle>{t("profile.title")}</PageTitle>
        <ProfileForm />
        <PasswordForm />
      </div>
    </RequireAuth>
  );
}
