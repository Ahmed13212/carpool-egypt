"use client";
import Link from "next/link";
import { useState, type FormEvent } from "react";
import { Alert, Button, Card, TextInput } from "@/components/ui";
import { useI18n } from "@/i18n";
import { api } from "@/lib/api";
import { isEmail } from "@/lib/validators";

export default function ForgotPasswordPage() {
  const { t, errorMessage } = useI18n();
  const [email, setEmail] = useState("");
  const [err, setErr] = useState<string>();
  const [formError, setFormError] = useState<string>();
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setFormError(undefined);
    if (!isEmail(email)) {
      setErr(t("validation.email"));
      return;
    }
    setErr(undefined);
    setBusy(true);
    try {
      await api("/auth/password-reset", {
        method: "POST",
        body: { email: email.trim() },
        auth: false,
      });
      setSent(true);
    } catch (e) {
      setFormError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="mx-auto max-w-md space-y-4">
      <h1 className="text-2xl font-bold text-brand-900">{t("forgot.title")}</h1>
      {sent ? (
        <>
          <Alert kind="success">{t("forgot.sent")}</Alert>
          <Link
            className="text-brand-700 underline"
            href={`/reset-password?email=${encodeURIComponent(email.trim())}`}
          >
            {t("forgot.have_code")}
          </Link>
        </>
      ) : (
        <form onSubmit={submit} noValidate className="space-y-4">
          <p className="text-sm text-gray-600">{t("forgot.text")}</p>
          {formError && <Alert kind="error">{formError}</Alert>}
          <TextInput
            id="email"
            type="email"
            label={t("auth.email")}
            value={email}
            error={err}
            onChange={(e) => setEmail(e.target.value)}
            dir="ltr"
          />
          <Button type="submit" className="w-full" loading={busy}>
            {t("forgot.submit")}
          </Button>
          <p className="text-sm">
            <Link className="text-brand-700 underline" href="/reset-password">
              {t("forgot.have_code")}
            </Link>
          </p>
        </form>
      )}
    </Card>
  );
}
