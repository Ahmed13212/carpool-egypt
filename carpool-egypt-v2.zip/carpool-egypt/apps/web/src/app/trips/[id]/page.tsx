"use client";
import { useParams, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { BookingPanel } from "@/components/booking-panel";
import { TripStatusBadge } from "@/components/status";
import { Alert, Badge, Button, Card, PageSpinner } from "@/components/ui";
import { useQuery } from "@/hooks/use-query";
import { useI18n } from "@/i18n";
import { ApiError, api } from "@/lib/api";
import { cityLabel, useCities } from "@/lib/cities";
import { formatDate, formatMoney, formatTime } from "@/lib/format";
import type { Trip } from "@/lib/types";

function TripContent() {
  const { id } = useParams<{ id: string }>();
  const sp = useSearchParams();
  const { t, locale, errorMessage } = useI18n();
  const { byId } = useCities();
  const {
    data: trip,
    error,
    loading,
    reload,
  } = useQuery(
    (signal) => api<Trip>(`/trips/${id}`, { auth: false, signal }),
    [id],
  );

  if (loading && !trip) return <PageSpinner />;
  if (error instanceof ApiError && error.status === 404)
    return <Alert kind="error">{t("trip.not_found")}</Alert>;
  if (error != null && !trip)
    return (
      <Alert kind="error">
        <div className="flex items-center justify-between gap-3">
          <span>{errorMessage(error)}</span>
          <Button variant="secondary" onClick={reload}>
            {t("common.retry")}
          </Button>
        </div>
      </Alert>
    );
  if (!trip) return null;

  const first = trip.stops[0],
    last = trip.stops[trip.stops.length - 1];
  const name = (s: Trip["stops"][number]) =>
    cityLabel(byId.get(s.cityId), locale, s.city);
  const stopById = new Map(trip.stops.map((s) => [s.id, s]));

  return (
    <div className="space-y-6">
      <header className="space-y-2">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="text-2xl font-bold text-brand-900 sm:text-3xl">
            {name(first)} → {name(last)}
          </h1>
          <TripStatusBadge status={trip.status} />
          <Badge tone={trip.bookingMode === "instant" ? "green" : "blue"}>
            {trip.bookingMode === "instant"
              ? t("results.instant")
              : t("results.approval")}
          </Badge>
        </div>
        <p className="text-gray-600">
          {formatDate(trip.departureAt, locale)} ·{" "}
          {formatTime(trip.departureAt, locale)} —{" "}
          {formatTime(trip.arrivalAt, locale)} · {t("common.cairo_time")}
        </p>
        {trip.status === "cancelled" && (
          <Alert kind="error">{t("trip.cancelled_notice")}</Alert>
        )}
      </header>

      <div className="grid gap-6 lg:grid-cols-[1fr_22rem]">
        <div className="space-y-6">
          <Card>
            <h2 className="mb-4 text-lg font-bold text-brand-900">
              {t("trip.stops")}
            </h2>
            <ol className="relative space-y-5 border-s-2 border-brand-600/30 ps-6">
              {trip.stops.map((s, i) => (
                <li key={s.id} className="relative">
                  <span
                    aria-hidden
                    className={`absolute -start-[1.95rem] top-1 size-3 rounded-full ${i === 0 || i === trip.stops.length - 1 ? "bg-brand-600" : "border-2 border-brand-600 bg-white"}`}
                  />
                  <p className="font-semibold">
                    {formatTime(s.estimatedAt, locale)} · {name(s)}
                  </p>
                  <p className="text-sm text-gray-600">{s.name}</p>
                </li>
              ))}
            </ol>
          </Card>

          <Card>
            <h2 className="mb-3 text-lg font-bold text-brand-900">
              {t("trip.availability")}
            </h2>
            <ul className="divide-y divide-black/5">
              {trip.segments.map((g) => {
                const a = stopById.get(g.fromStopId)!,
                  b = stopById.get(g.toStopId)!;
                return (
                  <li
                    key={g.seq}
                    className="flex flex-wrap items-center justify-between gap-2 py-2 text-sm"
                  >
                    <span>{t("trip.leg", { from: name(a), to: name(b) })}</span>
                    <span className="flex items-center gap-3">
                      <span className="font-medium">
                        {formatMoney(g.priceMinor, locale, trip.currency)}
                      </span>
                      <Badge tone={g.seatsAvailable > 0 ? "green" : "red"}>
                        {g.seatsAvailable === 1
                          ? t("results.seat_left")
                          : t("results.seats_left", { n: g.seatsAvailable })}
                      </Badge>
                    </span>
                  </li>
                );
              })}
            </ul>
          </Card>

          <Card className="grid gap-4 sm:grid-cols-2">
            <div>
              <h2 className="text-lg font-bold text-brand-900">
                {t("trip.driver")}
              </h2>
              <p className="mt-1 font-medium">{trip.driver.fullName}</p>
              {trip.driver.verified && (
                <Badge tone="green">{t("trip.verified")}</Badge>
              )}
            </div>
            <div>
              <h2 className="text-lg font-bold text-brand-900">
                {t("trip.vehicle")}
              </h2>
              <p className="mt-1">
                {trip.vehicle.make} {trip.vehicle.model} · {trip.vehicle.color}
              </p>
            </div>
            {trip.notes && (
              <div className="sm:col-span-2">
                <h2 className="text-lg font-bold text-brand-900">
                  {t("trip.notes")}
                </h2>
                <p className="mt-1 whitespace-pre-line text-gray-700">
                  {trip.notes}
                </p>
              </div>
            )}
          </Card>
        </div>

        <BookingPanel
          key={`${sp.get("from")}-${sp.get("to")}`}
          trip={trip}
          initial={{
            from: sp.get("from") ?? undefined,
            to: sp.get("to") ?? undefined,
            seats: Number(sp.get("seats") ?? 1),
          }}
          onBooked={reload}
        />
      </div>
    </div>
  );
}

export default function TripPage() {
  return (
    <Suspense fallback={<PageSpinner />}>
      <TripContent />
    </Suspense>
  );
}
