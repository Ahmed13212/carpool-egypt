"use client";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { SearchForm } from "@/components/search-form";
import { TripCard } from "@/components/trip-card";
import {
  Alert,
  Button,
  EmptyState,
  PageTitle,
  Pagination,
  Skeleton,
  SelectInput,
} from "@/components/ui";
import { useQuery } from "@/hooks/use-query";
import { useI18n } from "@/i18n";
import { api, qs } from "@/lib/api";
import type { Page, SearchItem } from "@/lib/types";

const PAGE_SIZE = 10;

function SearchContent() {
  const { t, errorMessage } = useI18n();
  const params = useSearchParams();
  const router = useRouter();
  const from = params.get("from") ?? "";
  const to = params.get("to") ?? "";
  const date = params.get("date") ?? "";
  const seats = Number(params.get("seats") ?? "1") || 1;
  const sort = params.get("sort") === "price" ? "price" : "departure";
  const page = Math.max(1, Number(params.get("page") ?? "1") || 1);
  const ready = !!from && !!to;

  const { data, error, loading, reload } = useQuery(
    (signal) =>
      api<Page<SearchItem>>(
        `/trips/search${qs({ fromCity: from, toCity: to, date, seats, sort, page, pageSize: PAGE_SIZE })}`,
        { auth: false, signal },
      ),
    [from, to, date, seats, sort, page],
    ready,
  );

  const setParam = (k: string, v: string) => {
    const q = new URLSearchParams(params.toString());
    q.set(k, v);
    if (k !== "page") q.delete("page");
    router.push(`/search?${q.toString()}`);
  };

  return (
    <div className="space-y-6">
      <PageTitle>{t("results.title")}</PageTitle>
      <SearchForm
        key={`${from}|${to}|${date}|${seats}`}
        initial={{ from, to, date, seats: String(seats) }}
      />

      {!ready && <EmptyState title={t("results.search_prompt")} />}

      {ready && loading && (
        <div
          className="space-y-3"
          role="status"
          aria-label={t("common.loading")}
        >
          <Skeleton className="h-36" />
          <Skeleton className="h-36" />
          <Skeleton className="h-36" />
        </div>
      )}

      {ready && error != null && (
        <Alert kind="error">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span>{errorMessage(error)}</span>
            <Button variant="secondary" onClick={reload}>
              {t("common.retry")}
            </Button>
          </div>
        </Alert>
      )}

      {ready &&
        !loading &&
        !error &&
        data &&
        (data.items.length === 0 ? (
          <EmptyState
            title={t("results.empty_title")}
            text={t("results.empty_text")}
          />
        ) : (
          <>
            <div className="flex flex-wrap items-end justify-between gap-3">
              <p className="font-medium text-gray-800" aria-live="polite">
                {data.total === 1
                  ? t("results.count_one")
                  : t("results.count", { n: data.total })}
              </p>
              <div className="w-56">
                <SelectInput
                  id="sort"
                  label={t("results.sort")}
                  value={sort}
                  onChange={(e) => setParam("sort", e.target.value)}
                >
                  <option value="departure">
                    {t("results.sort_departure")}
                  </option>
                  <option value="price">{t("results.sort_price")}</option>
                </SelectInput>
              </div>
            </div>
            <ul className="space-y-3">
              {data.items.map((i) => (
                <li key={i.tripId}>
                  <TripCard item={i} seats={seats} />
                </li>
              ))}
            </ul>
            <Pagination
              page={data.page}
              pages={Math.max(1, Math.ceil(data.total / data.pageSize))}
              onChange={(p) => setParam("page", String(p))}
            />
          </>
        ))}
      <p className="text-xs text-gray-500">
        {t("common.cairo_time")} {t("common.egp_hint")}
      </p>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense>
      <SearchContent />
    </Suspense>
  );
}
