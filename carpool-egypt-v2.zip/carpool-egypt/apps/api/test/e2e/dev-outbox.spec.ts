process.env.DEV_MAIL_OUTBOX = 'true';
import request from 'supertest';
import { loadEnv } from '../../src/config/env';
import { newUser, startHarness, Harness, PASSWORD, uniqueEmail } from '../helpers';

describe('dev mail outbox (explicitly enabled)', () => {
  let h: Harness;
  beforeAll(async () => {
    h = await startHarness();
  });
  afterAll(async () => {
    await h.close();
  });

  it('exposes verification and reset tokens only for the requested e-mail, and the token really verifies', async () => {
    const email = uniqueEmail();
    await request(h.http)
      .post('/api/v1/auth/register')
      .send({ email, password: PASSWORD, fullName: 'Dev Flow' })
      .expect(201);
    const other = await newUser(h);
    const out = await request(h.http)
      .get(`/api/v1/dev/outbox?email=${encodeURIComponent(email)}`)
      .expect(200);
    expect(out.body).toHaveLength(1);
    expect(out.body[0].kind).toBe('email_verification');
    expect(JSON.stringify(out.body)).not.toContain(other.email);
    await request(h.http).post('/api/v1/auth/verify-email').send({ token: out.body[0].token }).expect(204);
    expect((await request(h.http).get('/api/v1/meta')).body.devMailOutbox).toBe(true);
  });

  it('configuration refuses to start with the outbox enabled in production', () => {
    const base = {
      DATABASE_URL: 'postgres://x/y',
      JWT_ACCESS_SECRET: 'z'.repeat(40),
      DEV_MAIL_OUTBOX: 'true',
    };
    expect(() => loadEnv({ ...base, NODE_ENV: 'production' } as any)).toThrow(/DEV_MAIL_OUTBOX/);
    expect(loadEnv({ ...base, NODE_ENV: 'development' } as any).DEV_MAIL_OUTBOX).toBe(true);
  });
});
