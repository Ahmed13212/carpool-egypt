import request from 'supertest';
import {
  bearer,
  cityIds,
  futureAt,
  idemKey,
  newStaff,
  newUser,
  newVerifiedDriver,
  publishTrip,
  startHarness,
  Harness,
  TestUser,
} from '../helpers';

const api = '/api/v1';

describe('endpoints that support the web frontend', () => {
  let h: Harness;
  let reviewer: TestUser, admin: TestUser, finance: TestUser;
  beforeAll(async () => {
    h = await startHarness();
    [reviewer, admin, finance] = await Promise.all([
      newStaff(h, 'verification_reviewer'),
      newStaff(h, 'administrator'),
      newStaff(h, 'finance_operator'),
    ]);
  });
  afterAll(async () => {
    await h.close();
  });

  it('GET /cities is public and returns coordinates in both languages', async () => {
    const r = await request(h.http).get(`${api}/cities`).expect(200);
    const cairo = r.body.find((c: any) => c.slug === 'cairo');
    expect(cairo).toMatchObject({ nameAr: 'القاهرة', nameEn: 'Cairo' });
    expect(cairo.lat).toBeCloseTo(30.04, 1);
    expect(cairo.lng).toBeCloseTo(31.23, 1);
    expect(r.body.length).toBeGreaterThanOrEqual(20);
  });

  it('GET /meta reports feature flags and that mail is not really delivered', async () => {
    const r = await request(h.http).get(`${api}/meta`).expect(200);
    expect(r.body).toMatchObject({ currency: 'EGP', mailDelivery: false, devMailOutbox: false });
    expect(r.body.features).toEqual({ tripPublishing: true, booking: true, payments: false });
  });

  it('the dev mail outbox is closed by default', async () => {
    const u = await newUser(h);
    await request(h.http)
      .get(`${api}/dev/outbox?email=${encodeURIComponent(u.email)}`)
      .expect(404);
  });

  it('GET /me exposes the caller permissions (used by the UI only for display; the server still enforces)', async () => {
    const r = await request(h.http).get(`${api}/me`).set(bearer(reviewer.token)).expect(200);
    expect(r.body.permissions).toEqual(
      expect.arrayContaining(['verification:review', 'admin:dashboard:read']),
    );
    const p = await newUser(h);
    const me = await request(h.http).get(`${api}/me`).set(bearer(p.token)).expect(200);
    expect(me.body.permissions).toEqual(['booking:create']);
  });

  it('admin dashboard: staff only, live aggregate counts', async () => {
    const plain = await newUser(h);
    await request(h.http).get(`${api}/admin/dashboard`).set(bearer(plain.token)).expect(403);
    await request(h.http).get(`${api}/admin/dashboard`).expect(401);
    const r = await request(h.http).get(`${api}/admin/dashboard`).set(bearer(finance.token)).expect(200);
    expect(r.body.live).toBe(true);
    expect(r.body.users.total).toBeGreaterThan(0);
    expect(r.body.bookings).toHaveProperty('cancellationRate');
  });

  it('verification queue lists pending drivers/vehicles for reviewers only and shrinks after a decision', async () => {
    const d = await newUser(h, 'Queue Driver');
    await request(h.http).post(`${api}/drivers/apply`).set(bearer(d.token)).expect(200);
    const v = await request(h.http)
      .post(`${api}/vehicles`)
      .set(bearer(d.token))
      .send({ make: 'Hyundai', model: 'Accent', color: 'Grey', seats: 5, plateNumber: 'QQ 1234' })
      .expect(201);
    await request(h.http).get(`${api}/admin/verifications`).set(bearer(admin.token)).expect(403); // admin has no verification:review
    await request(h.http).get(`${api}/admin/verifications`).set(bearer(finance.token)).expect(403);
    const q = await request(h.http).get(`${api}/admin/verifications`).set(bearer(reviewer.token)).expect(200);
    expect(q.body.documentsReviewed).toBe(false);
    expect(q.body.drivers.some((x: any) => x.userId === d.id && x.fullName === 'Queue Driver')).toBe(true);
    expect(q.body.vehicles.some((x: any) => x.id === v.body.id && x.plateNumber === 'QQ 1234')).toBe(true);
    await request(h.http)
      .post(`${api}/admin/drivers/${d.id}/approve`)
      .set(bearer(reviewer.token))
      .expect(204);
    await request(h.http)
      .post(`${api}/admin/vehicles/${v.body.id}/approve`)
      .set(bearer(reviewer.token))
      .expect(204);
    const after = await request(h.http)
      .get(`${api}/admin/verifications`)
      .set(bearer(reviewer.token))
      .expect(200);
    expect(after.body.drivers.some((x: any) => x.userId === d.id)).toBe(false);
    expect(after.body.vehicles.some((x: any) => x.id === v.body.id)).toBe(false);
  });

  it('GET /me/bookings includes trip context (stops, cities, times, driver, trip status)', async () => {
    const driver = await newVerifiedDriver(h, reviewer);
    const trip = await publishTrip(h, driver, await cityIds(h), {
      departureAt: futureAt(12).toISOString(),
      bookingMode: 'instant',
    });
    const p = await newUser(h);
    await request(h.http)
      .post(`${api}/trips/${trip.id}/bookings`)
      .set(bearer(p.token))
      .set('Idempotency-Key', idemKey())
      .send({ fromStopId: trip.stops[1].id, toStopId: trip.stops[2].id, seats: 1 })
      .expect(201);
    const r = await request(h.http).get(`${api}/me/bookings`).set(bearer(p.token)).expect(200);
    expect(r.body.items[0]).toMatchObject({
      status: 'confirmed',
      tripStatus: 'scheduled',
      driverName: 'Driver Person',
      from: { city: 'minya' },
      to: { city: 'asyut' },
      priceTotalMinor: 8000,
    });
    expect(new Date(r.body.items[0].from.at).getTime()).toBeGreaterThan(Date.now());
  });
});

describe('payments cannot be switched on while no payment processing exists', () => {
  let h: Harness;
  beforeAll(async () => {
    h = await startHarness();
  });
  afterAll(async () => {
    await h.close();
  });

  it('PUT payments_enabled=true is refused (and false is accepted)', async () => {
    const admin = await newStaff(h, 'administrator');
    await request(h.http)
      .put('/api/v1/admin/settings/payments_enabled')
      .set(bearer(admin.token))
      .send({ value: true })
      .expect(409)
      .expect((r) => expect(r.body.error.code).toBe('payments_not_available'));
    await request(h.http)
      .put('/api/v1/admin/settings/payments_enabled')
      .set(bearer(admin.token))
      .send({ value: false })
      .expect(204);
    const s = await request(h.http).get('/api/v1/admin/settings').set(bearer(admin.token)).expect(200);
    expect(s.body.payments_enabled).toBe(false);
  });
});
