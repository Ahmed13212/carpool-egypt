import { Controller, Get, Inject, NotFoundException, Query } from '@nestjs/common';
import { z } from 'zod';
import { Public } from '../auth/auth.decorators';
import { DevMailer } from '../auth/mailer';
import { ZodPipe } from '../common/zod.pipe';
import { ENV, Env } from '../config/env';
import { SettingsService } from '../settings/settings.service';

@Controller()
export class MetaController {
  constructor(
    private readonly settings: SettingsService,
    private readonly mailer: DevMailer,
    @Inject(ENV) private readonly env: Env,
  ) {}

  /** Public feature/status flags so the UI can show what is switched on. */
  @Public()
  @Get('meta')
  async meta() {
    const s = await this.settings.getAll();
    return {
      currency: 'EGP',
      mailDelivery: false, // no real mail provider is implemented
      devMailOutbox: this.env.DEV_MAIL_OUTBOX,
      features: {
        tripPublishing: s.trip_publishing_enabled === true,
        booking: s.booking_enabled === true,
        payments: s.payments_enabled === true,
      },
    };
  }

  /** DEV ONLY (404 unless DEV_MAIL_OUTBOX=true, which is rejected in production). Lets a developer read mail tokens. */
  @Public()
  @Get('dev/outbox')
  outbox(@Query(new ZodPipe(z.object({ email: z.email() }))) q: { email: string }) {
    if (!this.env.DEV_MAIL_OUTBOX || this.env.NODE_ENV === 'production') throw new NotFoundException();
    return this.mailer.outbox
      .filter((m) => m.to.toLowerCase() === q.email.toLowerCase())
      .slice(-5)
      .map((m) => ({ kind: m.kind, token: m.token }));
  }
}
