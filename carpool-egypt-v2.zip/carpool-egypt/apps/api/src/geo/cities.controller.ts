import { Controller, Get } from '@nestjs/common';
import { Public } from '../auth/auth.decorators';
import { DatabaseService } from '../database/database.service';

@Controller('cities')
export class CitiesController {
  constructor(private readonly db: DatabaseService) {}

  /** Public list of active cities with centre coordinates (used by search and trip forms). */
  @Public()
  @Get()
  async list() {
    const { rows } = await this.db.query(
      `SELECT id, slug, name_ar, name_en, governorate_en, ST_Y(location::geometry) AS lat, ST_X(location::geometry) AS lng
         FROM cities WHERE is_active ORDER BY name_en`,
    );
    return rows.map((r: any) => ({
      id: r.id,
      slug: r.slug,
      nameAr: r.name_ar,
      nameEn: r.name_en,
      governorate: r.governorate_en,
      lat: r.lat,
      lng: r.lng,
    }));
  }
}
