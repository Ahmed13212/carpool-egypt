# Masar (مسار) — Egyptian carpooling platform · work in progress

A BlaBlaCar-style cost-sharing marketplace for intercity trips in Egypt: **Next.js** web app (Arabic RTL first, English available)
+ **NestJS** API + **PostgreSQL/PostGIS**.

> **Not production-ready.** It is a tested pre-launch build. Payments, e-mail/SMS delivery, notifications, document verification,
> messaging, reviews, MFA and the legal/licensing work are **not implemented**. See [`docs/status.md`](docs/status.md).

## What you can do in the app today
Register · verify e-mail (dev outbox only) · log in with rotating sessions · search trips by city/date/seats (route-aware, intermediate stops) ·
view trip details · book seats (instant or driver-approval) · see/cancel bookings · apply as a driver · add vehicles · publish multi-stop trips with
per-leg prices · approve/reject booking requests · cancel trips · admin: dashboard counts, driver/vehicle review queue, users (suspend/reinstate/roles),
audit log, platform switches. Arabic ⇄ English at any time.

## Quick start (any OS with Docker) — full stack
```bash
cp .env.docker.example .env        # then edit: POSTGRES_PASSWORD, JWT_ACCESS_SECRET
docker compose up --build -d       # db + api + web (applies migrations, seeds cities)
docker compose run --rm -e ADMIN_EMAIL=you@example.com -e ADMIN_PASSWORD='a-long-password' api node dist/scripts/create-admin.js
# open http://localhost:3000   (booking/publishing are OFF until an admin enables them under Admin → Settings)
```
**Windows?** Follow [`docs/windows-setup.md`](docs/windows-setup.md) (a PowerShell script automates it).
The Docker files were written but **not run** in the authoring environment; see "What was not tested".

## Development (Node 22+, database from Docker)
```bash
npm install
docker compose up -d db            # PostgreSQL+PostGIS only (needs POSTGRES_PASSWORD in .env)
cp .env.example apps/api/.env      # set DATABASE_URL (same password), JWT_ACCESS_SECRET (>=32 chars), DEV_MAIL_OUTBOX=true for local e-mail codes
npm run migrate && npm run seed:dev         # schema + cities; seed:dev also switches publishing/booking ON (local only)
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='a-long-password' npm run create-admin
npm run dev:api                    # http://localhost:4000  (terminal 1)
npm run dev:web                    # http://localhost:3000  (terminal 2) — proxies /api/v1 to the API
```
The browser only talks to the web origin; Next.js proxies `/api/v1/*` to the API (`API_URL`, default `http://localhost:4000`), so the refresh cookie is first-party.

## Scripts
| Command | Purpose |
|---|---|
| `npm run lint` / `typecheck` / `build` | static checks and production builds of both apps |
| `npm test` | API tests (needs `TEST_DATABASE_URL`, a **disposable** PostGIS database) + web tests |
| `npm run smoke` | end-to-end journey through the running stack (see `scripts/smoke.mjs`) |
| `npm run migrate`, `seed`, `seed:dev`, `create-admin` | database and bootstrap tasks |

## Layout
```
apps/api   NestJS API (auth, RBAC, trips, segment seat inventory, bookings, admin)   apps/web   Next.js app (ar/en)
database/  SQL migrations + city seed         scripts/  smoke test, Windows setup        docs/  guides and status
```

## Documents
[`docs/windows-setup.md`](docs/windows-setup.md) · [`docs/deployment.md`](docs/deployment.md) · [`docs/architecture.md`](docs/architecture.md) · [`docs/status.md`](docs/status.md) · [`docs/testing.md`](docs/testing.md)

## Legal notice
Technical controls do not make a transport service lawful. Egyptian transport licensing (Law 87/2018), personal-data protection (Law 151/2020),
payments, tax and insurance requirements have **not** been researched or satisfied here. Publishing/booking flags default to OFF for that reason.
