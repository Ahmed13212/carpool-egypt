// End-to-end smoke test through the Next.js origin (the same path a browser uses).
// Requires: API running with DEV_MAIL_OUTBOX=true, web running, flags enabled (seed --dev), and a staff account.
// Usage: BASE=http://localhost:3000 SMOKE_ADMIN_EMAIL=... SMOKE_ADMIN_PASSWORD=... node scripts/smoke.mjs
const BASE = process.env.BASE ?? 'http://localhost:3000';
const ADMIN = { email: process.env.SMOKE_ADMIN_EMAIL, password: process.env.SMOKE_ADMIN_PASSWORD };
if (!ADMIN.email || !ADMIN.password) { console.error('Set SMOKE_ADMIN_EMAIL and SMOKE_ADMIN_PASSWORD'); process.exit(2); }

let failures = 0, n = 0;
const ok = (cond, name, extra = '') => { n++; if (!cond) failures++; console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : '  -> ' + extra}`); return cond; };

class Client {
  constructor() { this.jar = new Map(); this.token = null; }
  async req(method, path, { body, headers = {}, auth = true } = {}) {
    const h = { ...headers };
    if (body !== undefined) h['content-type'] = 'application/json';
    if (auth && this.token) h.authorization = `Bearer ${this.token}`;
    if (this.jar.size) h.cookie = [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(BASE + path, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body), redirect: 'manual' });
    for (const c of res.headers.getSetCookie?.() ?? []) { const [kv] = c.split(';'); const i = kv.indexOf('='); this.jar.set(kv.slice(0, i), kv.slice(i + 1)); }
    const text = await res.text();
    let json; try { json = JSON.parse(text); } catch { /* html */ }
    return { status: res.status, json, text, headers: res.headers };
  }
}
const api = (c, m, p, o) => c.req(m, `/api/v1${p}`, o);
const uniq = () => Math.random().toString(36).slice(2, 10);
const PW = 'smoke-test-password-1';

async function register(name) {
  const c = new Client(); const email = `smoke-${uniq()}@example.test`;
  let r = await api(c, 'POST', '/auth/register', { auth: false, body: { email, password: PW, fullName: name, locale: 'en' } });
  ok(r.status === 201, `register ${name}`, JSON.stringify(r.json));
  r = await api(c, 'GET', `/dev/outbox?email=${encodeURIComponent(email)}`, { auth: false });
  const token = r.json?.find((m) => m.kind === 'email_verification')?.token;
  ok(!!token, `dev outbox returns verification token for ${name}`);
  r = await api(c, 'POST', '/auth/verify-email', { auth: false, body: { token } });
  ok(r.status === 204, `verify email ${name}`, r.text);
  r = await api(c, 'POST', '/auth/login', { auth: false, body: { email, password: PW } });
  ok(r.status === 200 && !!r.json?.accessToken, `login ${name}`, r.text);
  c.token = r.json.accessToken;
  ok(c.jar.has('refresh_token'), `refresh cookie stored via the Next proxy (${name})`);
  return { c, email, id: r.json.user.id };
}

(async () => {
  // ---------- pages render (server-side) ----------
  for (const [path, needle] of [['/', 'مسار'], ['/search', 'مسار'], ['/login', 'مسار'], ['/register', 'مسار'], ['/forgot-password', 'مسار']]) {
    const r = await new Client().req('GET', path);
    ok(r.status === 200 && r.text.includes('dir="rtl"') && r.text.includes('lang="ar"') && r.text.includes(needle), `page ${path} renders RTL Arabic by default`, `status ${r.status}`);
  }
  const en = await new Client().req('GET', '/', { headers: { cookie: 'locale=en' } });
  ok(en.status === 200 && en.text.includes('dir="ltr"') && en.text.includes('lang="en"') && en.text.includes('Share rides between Egyptian cities'), 'locale cookie switches page to English LTR');
  const sec = await new Client().req('GET', '/');
  ok(sec.headers.get('x-frame-options') === 'DENY' && sec.headers.get('x-content-type-options') === 'nosniff', 'web security headers present');
  ok(!sec.headers.get('x-powered-by'), 'x-powered-by hidden');
  const nf = await new Client().req('GET', '/definitely-missing');
  ok(nf.status === 404, '404 for unknown page');

  // ---------- public API through the proxy ----------
  const anon = new Client();
  let r = await api(anon, 'GET', '/cities', { auth: false });
  ok(r.status === 200 && r.json.length >= 20, 'GET /cities via proxy');
  const city = Object.fromEntries(r.json.map((c) => [c.slug, c]));
  r = await api(anon, 'GET', '/meta', { auth: false });
  ok(r.json?.features?.booking === true && r.json?.devMailOutbox === true && r.json?.features?.payments === false, 'meta: booking on, payments off, dev outbox on');
  r = await api(anon, 'GET', '/me', { auth: false });
  ok(r.status === 401, 'protected endpoint rejects anonymous');

  // ---------- staff ----------
  const admin = new Client();
  r = await api(admin, 'POST', '/auth/login', { auth: false, body: ADMIN });
  ok(r.status === 200, 'admin login', r.text); admin.token = r.json.accessToken;
  r = await api(admin, 'GET', '/me');
  ok(r.json.permissions.includes('verification:review'), 'admin /me exposes permissions');

  // ---------- driver journey ----------
  const driver = await register('Smoke Driver');
  r = await api(driver.c, 'POST', '/drivers/apply');
  ok(r.status === 200 && r.json.verificationStatus === 'pending_review', 'driver applies');
  r = await api(driver.c, 'POST', '/vehicles', { body: { make: 'Toyota', model: 'Corolla', color: 'White', seats: 5, plateNumber: `SM ${Math.floor(1000 + Math.random() * 8999)}` } });
  ok(r.status === 201, 'driver adds vehicle', r.text); const vehicleId = r.json.id;
  const dep = new Date(Date.now() + 4 * 86400_000); dep.setUTCHours(9, 0, 0, 0);
  const tripBody = (extra = {}) => ({ vehicleId, departureAt: dep.toISOString(), seatsTotal: 2, bookingMode: 'approval',
    stops: [{ cityId: city.cairo.id, name: 'Cairo meeting point', lat: city.cairo.lat, lng: city.cairo.lng, offsetMinutes: 0 },
            { cityId: city.minya.id, name: 'Minya station', lat: city.minya.lat, lng: city.minya.lng, offsetMinutes: 240 },
            { cityId: city.asyut.id, name: 'Asyut station', lat: city.asyut.lat, lng: city.asyut.lng, offsetMinutes: 360 }],
    segmentPricesMinor: [10000, 8000], ...extra });
  r = await api(driver.c, 'POST', '/trips', { body: tripBody() });
  ok(r.status === 403, 'unapproved driver cannot publish (server-enforced)', `status ${r.status}`);
  r = await api(admin, 'GET', '/admin/verifications');
  ok(r.json.drivers.some((d) => d.userId === driver.id) && r.json.vehicles.some((v) => v.id === vehicleId), 'verification queue shows the applicant and vehicle');
  r = await api(admin, 'POST', `/admin/drivers/${driver.id}/approve`); ok(r.status === 204, 'reviewer approves driver');
  r = await api(admin, 'POST', `/admin/vehicles/${vehicleId}/approve`); ok(r.status === 204, 'reviewer approves vehicle');
  r = await api(driver.c, 'POST', '/trips', { body: tripBody() });
  ok(r.status === 201, 'approved driver publishes trip', r.text);
  const trip = r.json;
  r = await api(driver.c, 'POST', '/trips', { body: tripBody() });
  ok(r.status === 409 && r.json.error.code === 'trip_overlap', 'overlapping trip rejected');

  // ---------- passenger journey ----------
  const pass = await register('Smoke Passenger');
  const date = dep.toISOString().slice(0, 10);
  r = await api(pass.c, 'GET', `/trips/search?fromCity=cairo&toCity=asyut&date=${date}&seats=2`, { auth: false });
  const hit = r.json?.items?.find((i) => i.tripId === trip.id);
  ok(!!hit && hit.pricePerSeatMinor === 18000 && hit.seatsAvailable === 2, 'search finds the trip with summed segment price');
  r = await api(pass.c, 'GET', `/trips/search?fromCity=asyut&toCity=cairo&date=${date}`, { auth: false });
  ok(!r.json.items.some((i) => i.tripId === trip.id), 'search is direction-aware');
  const body = { fromStopId: trip.stops[0].id, toStopId: trip.stops[2].id, seats: 2 };
  r = await api(pass.c, 'POST', `/trips/${trip.id}/bookings`, { body });
  ok(r.status === 400 && r.json.error.code === 'idempotency_key_required', 'booking requires Idempotency-Key');
  const key = `smoke-${uniq()}-${uniq()}`;
  r = await api(pass.c, 'POST', `/trips/${trip.id}/bookings`, { body, headers: { 'idempotency-key': key } });
  ok(r.status === 201 && r.json.status === 'pending_approval' && r.json.priceTotalMinor === 36000, 'passenger books (needs driver approval)', r.text);
  const booking = r.json;
  r = await api(pass.c, 'POST', `/trips/${trip.id}/bookings`, { body, headers: { 'idempotency-key': key } });
  ok(r.status === 200 && r.json.id === booking.id && r.headers.get('idempotent-replay') === 'true', 'retry with same key replays, no duplicate');
  r = await api(pass.c, 'GET', `/trips/search?fromCity=cairo&toCity=minya&date=${date}`, { auth: false });
  ok(!r.json.items.some((i) => i.tripId === trip.id), 'fully booked trip disappears from search');
  const other = await register('Smoke Other');
  r = await api(other.c, 'GET', `/bookings/${booking.id}`);
  ok(r.status === 404, 'other passenger cannot read the booking (IDOR)');
  r = await api(pass.c, 'POST', `/bookings/${booking.id}/confirm`);
  ok(r.status === 404, 'passenger cannot approve own booking');
  r = await api(driver.c, 'GET', `/trips/${trip.id}/bookings`);
  ok(r.json.items.length === 1 && r.json.items[0].passengerName === 'Smoke Passenger', 'driver sees booking request with passenger name');
  r = await api(driver.c, 'POST', `/bookings/${booking.id}/confirm`);
  ok(r.status === 200 && r.json.status === 'confirmed', 'driver approves booking');
  r = await api(pass.c, 'GET', '/me/bookings');
  ok(r.json.items[0].status === 'confirmed' && r.json.items[0].from.city === 'cairo' && r.json.items[0].to.city === 'asyut', 'passenger dashboard data shows confirmed booking with route');
  r = await api(pass.c, 'POST', `/bookings/${booking.id}/cancel`, { body: { reason: 'smoke' } });
  ok(r.status === 200 && r.json.status === 'cancelled', 'passenger cancels');
  r = await api(anon, 'GET', `/trips/${trip.id}`, { auth: false });
  ok(r.json.segments.every((s) => s.seatsAvailable === 2), 'seats returned to inventory after cancellation');
  r = await api(pass.c, 'GET', '/admin/dashboard');
  ok(r.status === 403, 'passenger forbidden from admin API');

  // ---------- session handling through the proxy ----------
  const csrf = await api(pass.c, 'POST', '/auth/refresh', { auth: false });
  ok(csrf.status === 403, 'refresh without X-Requested-With is blocked (CSRF)');
  const old = pass.c.jar.get('refresh_token');
  r = await api(pass.c, 'POST', '/auth/refresh', { auth: false, headers: { 'x-requested-with': 'fetch' } });
  ok(r.status === 200 && !!r.json.accessToken && pass.c.jar.get('refresh_token') !== old, 'refresh rotates the cookie via proxy');
  const thief = new Client(); thief.jar.set('refresh_token', old);
  r = await api(thief, 'POST', '/auth/refresh', { auth: false, headers: { 'x-requested-with': 'fetch' } });
  ok(r.status === 401, 'replaying the old refresh token is rejected');
  r = await api(pass.c, 'POST', '/auth/refresh', { auth: false, headers: { 'x-requested-with': 'fetch' } });
  ok(r.status === 401, 'theft detection revoked the legitimate session too');

  // ---------- admin ----------
  r = await api(admin, 'GET', '/admin/dashboard');
  ok(r.status === 200 && r.json.live === true && r.json.bookings.total >= 1, 'admin dashboard returns live counts');
  r = await api(admin, 'PUT', '/admin/settings/payments_enabled', { body: { value: true } });
  ok(r.status === 409 && r.json.error.code === 'payments_not_available', 'payments cannot be enabled');
  r = await api(admin, 'POST', `/admin/users/${other.id}/suspend`, { body: { reason: 'smoke test' } });
  ok(r.status === 204, 'admin suspends user');
  r = await api(other.c, 'GET', '/me');
  ok(r.status === 401, 'suspended user is cut off immediately');
  r = await api(admin, 'GET', '/admin/audit-logs?pageSize=50');
  const actions = new Set(r.json.items.map((l) => l.action));
  ok(['driver.approved', 'vehicle.approved', 'user.suspended'].every((a) => actions.has(a)), 'audit log recorded the admin actions');
  r = await api(driver.c, 'POST', `/trips/${trip.id}/cancel`, { body: { reason: 'smoke cleanup' } });
  ok(r.status === 200 && r.json.status === 'cancelled', 'driver cancels trip');

  console.log(`\n${n - failures}/${n} checks passed`);
  process.exit(failures ? 1 : 0);
})().catch((e) => { console.error('SMOKE CRASH', e); process.exit(1); });
