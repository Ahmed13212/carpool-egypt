<#
  Masar - Windows first-time setup (PowerShell 5.1+ or 7).  NOT executed in the authoring sandbox (no Windows).
  Run from the project root:   powershell -ExecutionPolicy Bypass -File scripts\windows\setup.ps1
  What it does: checks Node/Docker, creates .env files with generated secrets (never overwrites existing ones),
  starts PostgreSQL+PostGIS in Docker, installs dependencies, runs migrations, seeds cities (+ dev flags).
#>
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path "$PSScriptRoot\..\..")

function Fail($m) { Write-Host "ERROR: $m" -ForegroundColor Red; exit 1 }
function RandomSecret($bytes) {
  $b = New-Object byte[] $bytes
  [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
  return ([Convert]::ToBase64String($b) -replace '[^A-Za-z0-9]', '')
}

# 1. prerequisites
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Fail "Node.js 22+ not found. Install it from https://nodejs.org (LTS 22 or newer)." }
$major = [int]((node -v) -replace '^v(\d+).*', '$1')
if ($major -lt 22) { Fail "Node.js $major found; version 22 or newer is required." }
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { Fail "Docker not found. Install Docker Desktop, or follow docs\windows-setup.md (native PostgreSQL route)." }
docker info *> $null
if ($LASTEXITCODE -ne 0) { Fail "Docker is installed but not running. Start Docker Desktop and retry." }

# 2. environment files (secrets are generated locally and never printed)
$rootEnv = Join-Path (Get-Location) ".env"
$apiEnv  = Join-Path (Get-Location) "apps\api\.env"
if ((Test-Path $rootEnv) -or (Test-Path $apiEnv)) {
  Write-Host "Existing .env files found - leaving them untouched." -ForegroundColor Yellow
} else {
  $dbPass = RandomSecret 24
  $jwt    = RandomSecret 48
  Set-Content -Path $rootEnv -Encoding ascii -Value @(
    "POSTGRES_PASSWORD=$dbPass", "JWT_ACCESS_SECRET=$jwt", "APP_ENV=development", "DEV_MAIL_OUTBOX=true")
  Set-Content -Path $apiEnv -Encoding ascii -Value @(
    "NODE_ENV=development", "PORT=4000",
    "DATABASE_URL=postgres://carpool:$dbPass@localhost:5432/carpool",
    "JWT_ACCESS_SECRET=$jwt", "ACCESS_TOKEN_TTL_SECONDS=900", "REFRESH_TOKEN_TTL_DAYS=30",
    "CORS_ORIGINS=", "TRUST_PROXY=true", "RATE_LIMIT_ENABLED=true", "RATE_LIMIT_AUTH_PER_MINUTE=10",
    "PASSWORD_SCRYPT_N=32768", "DEV_MAIL_OUTBOX=true")
  Write-Host "Created .env and apps\api\.env with generated secrets."
}

# 3. database
Write-Host "Starting PostgreSQL + PostGIS (docker compose up -d db) ..."
docker compose up -d db
if ($LASTEXITCODE -ne 0) { Fail "docker compose failed." }
Write-Host "Waiting for the database to become healthy ..."
for ($i = 0; $i -lt 40; $i++) {
  $state = docker inspect --format '{{.State.Health.Status}}' (docker compose ps -q db)
  if ($state -eq 'healthy') { break }
  Start-Sleep -Seconds 3
}
if ($state -ne 'healthy') { Fail "Database did not become healthy. Run: docker compose logs db" }

# 4. dependencies, schema, reference data
npm install;            if ($LASTEXITCODE -ne 0) { Fail "npm install failed." }
npm run migrate;        if ($LASTEXITCODE -ne 0) { Fail "migrations failed." }
npm run seed:dev;       if ($LASTEXITCODE -ne 0) { Fail "seeding failed." }

Write-Host ""
Write-Host "Setup complete." -ForegroundColor Green
Write-Host "Next:"
Write-Host '  1. Create the first administrator (pick your own email/password):'
Write-Host '       $env:ADMIN_EMAIL="you@example.com"; $env:ADMIN_PASSWORD="a-long-password-here"; npm run create-admin'
Write-Host '       Remove-Item Env:ADMIN_PASSWORD'
Write-Host '  2. Terminal A:  npm run dev:api     (http://localhost:4000)'
Write-Host '  3. Terminal B:  npm run dev:web     (http://localhost:3000)'
